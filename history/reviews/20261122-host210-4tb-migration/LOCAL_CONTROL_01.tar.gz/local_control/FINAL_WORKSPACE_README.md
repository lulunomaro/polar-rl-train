# RoboMaster 4TB 工作区

主机：原210，当前10.24.3.125；用户egde。
磁盘：/dev/sda3，UUID AFEF50F71FC9187D，已设置开机自动挂载 /mnt/robowork4t。
工作区：/mnt/robowork4t/workspaces/robomaster。
打开本目录的 robomaster.code-workspace 可查看四个数据/记录目录。

- mjcf/：原本机 C:/Users/lulu/Desktop/claude/mjcf，可读部分115861个原始文件/56259308498字节，后续Git新增文件另有增量凭据。
- history/local_F/RMPOLAR-RL/：本机F盘选中的34项历史训练目录/包，原始252078个文件/84281443742字节。
- history/host210/mod4_windows_data/：旧服务器292项历史训练数据，302777个普通文件/425486607935字节。
- migration/：清单、逐文件SHA256、失败原记录、独立恢复、落盘和迁移回执。

原始可读数据总计670716个普通文件/566027360175字节；新Git文件和迁移报告通过独立增量同步。
全部原始文件校验完成。旧服务器源件已清理，292个原入口指向新盘，/home/egde/rl_candidates仍沿用原入口。
本机源文件清理及Git归档的逐阶段状态见migration与主仓库history/reviews/20261122-host210-4tb-migration。

权限例外：原C盘 rmuc2026_work/unpack_verify_4zomhj13 无法读取，内容和大小未知，不计入上述分母，原件保留在本机；之前的Windows管理员授权被取消。
61个旧日志按源盘只读区段取回并逐条通过TFRecord CRC32C/目标SHA256；一个含回车符的历史文件保存为 mod4v3_model__trailing_CR.json，原正常文件另存不覆盖。
52个WSL/Linux链接已按原始目标恢复；11个原有悬空链接与2个本机Node运行库外部引用按历史原意保留。LQR主仓库和配套工作树的两处Git指针已改为新盘路径，原提交保持。

Windows虚拟环境和历史绝对路径作为原文件保存，后续运行按Linux主机配置依赖。
以前的试错、失败、模型、RNG、检查点和once标记按原字节迁移；本轮工作为存储迁移。
