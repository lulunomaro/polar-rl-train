# mjcf 工作区迁移去向

原目录：C:/Users/lulu/Desktop/claude/mjcf
新工作区：egde@10.24.3.125:/mnt/robowork4t/workspaces/robomaster
项目文件：/mnt/robowork4t/workspaces/robomaster/mjcf

连接原210主机后，打开新工作区下的 robomaster.code-workspace。
原文件在完整复制、SHA256校验和目标盘落盘之后清理。
rmuc2026_work/unpack_verify_4zomhj13 的Windows权限仍需管理员处理，未读取的原件保留在本机。
本轮Git归档所需的临时管理副本在最终同步核验后清理。
迁移记录：C:/Users/lulu/.codex/migrations/210_4tb_20261122
