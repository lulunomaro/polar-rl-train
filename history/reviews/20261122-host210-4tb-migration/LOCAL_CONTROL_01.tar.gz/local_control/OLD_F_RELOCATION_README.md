# 历史训练文件迁移去向

选定的历史训练目录与归档已迁往：
egde@10.24.3.125:/mnt/robowork4t/workspaces/robomaster/history/local_F/RMPOLAR-RL

当前v4 CAD、toolchains及未选中的本机工具目录保持原位置。
完整清单和SHA256见新工作区 migration/，本机控制记录位于 C:/Users/lulu/.codex/migrations/210_4tb_20261122。
