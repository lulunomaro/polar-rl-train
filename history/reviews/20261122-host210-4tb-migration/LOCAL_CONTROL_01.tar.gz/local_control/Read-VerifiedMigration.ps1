function Get-VerifiedMigrationRecords {
    param([switch]$RequireComplete)
    $ErrorActionPreference = 'Stop'
    $controlRoot = 'C:\Users\lulu\.codex\migrations\210_4tb_20261122'
    $original = Get-Content -LiteralPath (Join-Path $controlRoot 'native_parallel_state.json') -Raw -Encoding utf8 | ConvertFrom-Json
    if ($RequireComplete) {
        if ($original.verified_files -ne 367939 -or $original.verified_bytes -ne 140540752240) { throw 'Original copies are incomplete' }
        foreach ($value in $original.worker_exit_codes.PSObject.Properties.Value) { if ($null -eq $value -or $value -ne 0) { throw 'An original worker is not finished successfully' } }
        $flush = Get-Content -LiteralPath (Join-Path $controlRoot 'target_final_flush_receipt.json') -Raw -Encoding utf8 | ConvertFrom-Json
        if ($flush.status -ne 'completed' -or $flush.returncode -ne 0) { throw 'Final target flush is not complete' }
    }
    $allowedRoots = @('C:\Users\lulu\Desktop\claude\mjcf', 'F:\RMPOLAR-RL')
    $records = [Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
    $manifests = [Collections.Generic.List[object]]::new()
    $legacy = @('mjcf_0001_verified.json','mjcf_0002_verified.json','mjcf_0003_verified.json','mjcf_0007_verified.json')
    $receipts = @(Get-ChildItem -LiteralPath $controlRoot -File -Filter '*_verified.json' | Where-Object { $_.Name -match '^(mjcf|F_training)_\d{4}_verified\.json$' } | Sort-Object Name)
    $receipts += @(Get-ChildItem -LiteralPath $controlRoot -File -Filter 'local_delta_*_verified.json' | Where-Object { $_.Name -match '^local_delta_\d+_verified\.json$' } | Sort-Object Name)
    foreach ($receiptFile in $receipts) {
        $receipt = Get-Content -LiteralPath $receiptFile.FullName -Raw -Encoding utf8 | ConvertFrom-Json
        if ($receipt.status -ne 'verified') { throw ('Unverified receipt '+$receiptFile.Name) }
        if ($receipt.content_sha256_verified -ne $true -and $receiptFile.Name -notin $legacy) { throw 'Missing source/target SHA verification' }
        $manifestPath = Join-Path $controlRoot ($receiptFile.Name -replace '_verified\.json$', '_manifest.json')
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding utf8 | ConvertFrom-Json
        $groups = if ($manifest.PSObject.Properties.Name -contains 'groups') { @($manifest.groups) } else { @($manifest) }
        $batchFiles = 0; $batchBytes = 0L
        foreach ($group in $groups) {
            $sourceRoot = [IO.Path]::GetFullPath([string]$group.source_root).TrimEnd('\')
            if ($sourceRoot -notin $allowedRoots) { throw ('Unexpected source root '+$sourceRoot) }
            foreach ($row in $group.files) {
                $rel = ([string]$row.path).Replace('/','\')
                if ([IO.Path]::IsPathRooted($rel) -or ($rel.Split('\') -contains '..')) { throw 'Invalid relative source path' }
                $full = [IO.Path]::GetFullPath((Join-Path $sourceRoot $rel))
                if (-not $full.StartsWith($sourceRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Source escaped the approved root' }
                if ([string]$row.sha256 -notmatch '^[0-9a-f]{64}$') { throw 'Missing file SHA256' }
                $keep = $false
                if ($sourceRoot -eq $allowedRoots[0]) {
                    $keep = $rel.StartsWith('polar-rl-train\.git\',[StringComparison]::OrdinalIgnoreCase) -or $rel -in @('polar-rl-train\.gitignore','polar-rl-train\.gitattributes','polar-rl-train\archive_tools\record_experiment.py','polar-rl-train\archive_tools\capture_history.py')
                }
                $records[$full] = [pscustomobject]@{ Path=$full; Root=$sourceRoot; Relative=$rel; Bytes=[long]$row.bytes; MtimeNs=[long]$row.mtime_ns; ExpectedTicks=(621355968000000000L+[long]([decimal]$row.mtime_ns/100)); Sha256=[string]$row.sha256; KeepTemporaryEvidence=$keep }
                $batchFiles++; $batchBytes += [long]$row.bytes
            }
        }
        if ($batchFiles -ne $receipt.files -or $batchBytes -ne $receipt.bytes) { throw ('Manifest/receipt mismatch '+$receiptFile.Name) }
        $manifests.Add([pscustomobject]@{Path=$manifestPath;Files=$batchFiles;Bytes=$batchBytes})
    }
    [pscustomobject]@{ Records=$records; Manifests=$manifests; OriginalFiles=$original.verified_files; OriginalBytes=$original.verified_bytes; RequireComplete=[bool]$RequireComplete }
}

