$ErrorActionPreference='Stop'
$controlRoot='C:\Users\lulu\.codex\migrations\210_4tb_20261122'
$regular=Get-Content -LiteralPath (Join-Path $controlRoot 'local_regular_cleanup_state.json') -Raw -Encoding utf8 | ConvertFrom-Json
if ($regular.status -ne 'verified_regular_files_removed_pending_links_directories_and_temporary_git') { throw 'Wait for the existing regular-file cleanup to finish' }
$flush=Get-Content -LiteralPath (Join-Path $controlRoot 'target_final_flush_receipt.json') -Raw -Encoding utf8 | ConvertFrom-Json
if ($flush.status -ne 'completed' -or $flush.returncode -ne 0) { throw 'Final target flush missing' }
$linkProof=Get-Content -LiteralPath (Join-Path $controlRoot 'source_link_repair_result_receipt_01.json') -Raw -Encoding utf8 | ConvertFrom-Json
if ($linkProof.status -ne 'raw_original_links_restored' -or $linkProof.unexpected_missing_targets.Count -ne 0) { throw 'Stored source links have not been faithfully migrated' }
$roots=@('C:\Users\lulu\Desktop\claude\mjcf','F:\RMPOLAR-RL')
$gitRoot=Join-Path $roots[0] 'polar-rl-train\.git'
$evidenceRoot=Join-Path $roots[0] 'polar-rl-train'
$protected='C:\Users\lulu\Desktop\claude\mjcf\rmuc2026_work\unpack_verify_4zomhj13'
$statePath=Join-Path $controlRoot 'local_links_directories_cleanup_state.json'
if (Test-Path -LiteralPath $statePath) { throw 'Follow the saved link/directory cleanup state instead of restarting' }
$state=[ordered]@{status='removing_migrated_link_nodes';pid=$PID;started_at=[DateTime]::UtcNow.ToString('o');removed_links=0;removed_empty_directories=0;already_absent=0;retained_link_errors=0;retained_directory_errors=0;retained_nonempty_directories=0;protected_acl_directory=$protected;kept_temporary_git=$evidenceRoot;finished_at=$null}
function Save-State { [IO.File]::WriteAllText($statePath,($state | ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false)) }
$checkedParents=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($root in $roots) { [void]$checkedParents.Add($root) }
function Assert-Scope([string]$value,[string]$root) {
    $full=[IO.Path]::GetFullPath($value);$root=[IO.Path]::GetFullPath($root)
    if ($root -notin $roots -or -not $full.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw ('Out of scope path '+$full) }
    $parent=[IO.Path]::GetDirectoryName($full)
    while (-not $checkedParents.Contains($parent)) {
        if (-not $parent.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Ancestor escaped source root' }
        $item=Get-Item -LiteralPath $parent -Force
        if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw ('Unexpected reparse ancestor '+$parent) }
        [void]$checkedParents.Add($parent)
        $parent=[IO.Path]::GetDirectoryName($parent)
    }
    return $full
}
Save-State
$events=[IO.StreamWriter]::new((Join-Path $controlRoot 'local_links_directories_cleanup_events.jsonl'),$false,[Text.UTF8Encoding]::new($false))
try {
    $links=(Get-Content -LiteralPath (Join-Path $controlRoot 'source_links_cleanup_identity_01.json') -Raw -Encoding utf8 | ConvertFrom-Json).links
    foreach ($row in $links) {
        $path=$row.path
        try {
            $path=Assert-Scope $path $row.root
            $item=Get-Item -LiteralPath $path -Force -ErrorAction Stop
            if (-not ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.LastWriteTimeUtc.Ticks -ne [long]$row.expected_ticks) { throw 'Source link identity changed after raw-target capture' }
            if ($item.PSIsContainer) { [IO.Directory]::Delete($path,$false) } else { [IO.File]::Delete($path) }
            $state.removed_links++
        } catch [System.Management.Automation.ItemNotFoundException] { $state.already_absent++ }
        catch { $state.retained_link_errors++;$events.WriteLine((@{status='retained_link_error';path=$path;error=$_.Exception.Message} | ConvertTo-Json -Compress)) }
    }
    $state.status='removing_only_empty_source_directories';Save-State
    $structure=Get-Content -LiteralPath (Join-Path $controlRoot 'structure_plan.json') -Raw -Encoding utf8 | ConvertFrom-Json
    $dirs=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($remote in $structure.directories) {
        $prefixC='/mnt/robowork4t/workspaces/robomaster/mjcf/'
        $prefixF='/mnt/robowork4t/workspaces/robomaster/history/local_F/RMPOLAR-RL/'
        if ($remote.StartsWith($prefixC,[StringComparison]::Ordinal)) { $path=Join-Path $roots[0] $remote.Substring($prefixC.Length).Replace('/','\') }
        elseif ($remote.StartsWith($prefixF,[StringComparison]::Ordinal)) { $path=Join-Path $roots[1] $remote.Substring($prefixF.Length).Replace('/','\') }
        else { continue }
        [void]$dirs.Add([IO.Path]::GetFullPath($path))
    }
    $counter=0
    foreach ($path in ($dirs | Sort-Object Length -Descending)) {
        if ($path -eq $gitRoot -or $path.StartsWith($gitRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { continue }
        if ($path -eq $evidenceRoot -or $path -eq (Join-Path $evidenceRoot 'archive_tools')) { continue }
        if ($path -eq $protected -or $protected.StartsWith($path+'\',[StringComparison]::OrdinalIgnoreCase)) { continue }
        try {
            $root=if ($path.StartsWith($roots[0]+'\',[StringComparison]::OrdinalIgnoreCase)) { $roots[0] } else { $roots[1] }
            [void](Assert-Scope $path $root)
            $item=Get-Item -LiteralPath $path -Force -ErrorAction Stop
            if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Expected an ordinary source directory' }
            $children=[IO.Directory]::EnumerateFileSystemEntries($path).GetEnumerator()
            try { $nonempty=$children.MoveNext() } finally { $children.Dispose() }
            if ($nonempty) { $state.retained_nonempty_directories++;continue }
            if ($item.Attributes -band [IO.FileAttributes]::ReadOnly) { [IO.File]::SetAttributes($path,($item.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly))) }
            [IO.Directory]::Delete($path,$false)
            $state.removed_empty_directories++
        } catch [System.Management.Automation.ItemNotFoundException] { $state.already_absent++ }
        catch { $state.retained_directory_errors++;$events.WriteLine((@{status='retained_directory_error';path=$path;error=$_.Exception.Message} | ConvertTo-Json -Compress)) }
        $counter++;if (($counter % 500) -eq 0) { $events.Flush();Save-State }
    }
    $state.status='source_links_and_empty_directories_processed';$state.finished_at=[DateTime]::UtcNow.ToString('o');Save-State
} finally { $events.Dispose() }
$state | ConvertTo-Json -Depth 5

