$ErrorActionPreference = 'Stop'
$controlRoot = 'C:\Users\lulu\.codex\migrations\210_4tb_20261122'
. (Join-Path $controlRoot 'Read-VerifiedMigration.ps1')
$plan = Get-VerifiedMigrationRecords -RequireComplete
$roots = @('C:\Users\lulu\Desktop\claude\mjcf','F:\RMPOLAR-RL')
foreach ($driveLetter in @('C:','F:')) {
    $driveInfo = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='"+$driveLetter+"'")
    if ($driveInfo.DriveType -ne 3 -or $driveInfo.FileSystem -ne 'NTFS') { throw 'The source must be the identified local NTFS volume' }
}
$checkedParents = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($root in $roots) {
    $info = Get-Item -LiteralPath $root -Force
    if (-not $info.PSIsContainer -or ($info.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'An approved source root changed type' }
    [void]$checkedParents.Add($root)
}
$statePath = Join-Path $controlRoot 'local_regular_cleanup_state.json'
if (Test-Path -LiteralPath $statePath) { throw 'Follow the existing cleanup job and receipt instead of restarting it' }
$state = [ordered]@{status='removing_verified_regular_files';pid=$PID;started_at=[DateTime]::UtcNow.ToString('o');unique_records=$plan.Records.Count;removed_files=0;removed_bytes=0L;retained_changed=0;retained_errors=0;already_absent=0;kept_temporary_evidence=0;source_removal_started=$true;known_acl_directory='C:\Users\lulu\Desktop\claude\mjcf\rmuc2026_work\unpack_verify_4zomhj13';checked_at=$null;finished_at=$null}
function Save-CleanupState {
    $state.checked_at=[DateTime]::UtcNow.ToString('o')
    $tempPath=$statePath+'.tmp'
    [IO.File]::WriteAllText($tempPath,($state | ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
    [IO.File]::Move($tempPath,$statePath,$true)
}
function Assert-SourceParent([string]$filePath,[string]$root) {
    $full=[IO.Path]::GetFullPath($filePath)
    if ($root -notin $roots -or -not $full.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw ('Out of scope source '+$filePath) }
    $parent=[IO.Path]::GetDirectoryName($full)
    while (-not $checkedParents.Contains($parent)) {
        if (-not $parent.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Source ancestor escaped its root' }
        $entry=Get-Item -LiteralPath $parent -Force
        if (-not $entry.PSIsContainer -or ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw ('Unexpected source reparse ancestor '+$parent) }
        [void]$checkedParents.Add($parent)
        $parent=[IO.Path]::GetDirectoryName($parent)
    }
    return $full
}
Save-CleanupState
$timer=[Diagnostics.Stopwatch]::StartNew()
$events=[IO.StreamWriter]::new((Join-Path $controlRoot 'local_regular_cleanup_events.jsonl'),$false,[Text.UTF8Encoding]::new($false))
try {
    foreach ($record in $plan.Records.Values) {
        if ($record.KeepTemporaryEvidence) { $state.kept_temporary_evidence++; continue }
        $path=$record.Path
        try {
            $path=Assert-SourceParent $path $record.Root
            $item=Get-Item -LiteralPath $path -Force -ErrorAction Stop
            if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'A verified regular file changed type' }
            if ($item.Length -ne $record.Bytes -or $item.LastWriteTimeUtc.Ticks -ne $record.ExpectedTicks) {
                $state.retained_changed++; $events.WriteLine((@{status='retained_metadata_changed';path=$path} | ConvertTo-Json -Compress)); continue
            }
            $actual=(Get-FileHash -LiteralPath $path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
            $after=Get-Item -LiteralPath $path -Force
            if ($actual -ne $record.Sha256 -or $after.Length -ne $record.Bytes -or $after.LastWriteTimeUtc.Ticks -ne $record.ExpectedTicks) {
                $state.retained_changed++; $events.WriteLine((@{status='retained_content_changed';path=$path;actual_sha256=$actual} | ConvertTo-Json -Compress)); continue
            }
            Remove-Item -LiteralPath $path -Force -Confirm:$false -ErrorAction Stop
            $state.removed_files++; $state.removed_bytes += $record.Bytes
        } catch [System.Management.Automation.ItemNotFoundException] {
            $state.already_absent++; $events.WriteLine((@{status='already_absent';path=$path} | ConvertTo-Json -Compress))
        } catch {
            $state.retained_errors++; $events.WriteLine((@{status='retained_error';path=$path;error=$_.Exception.Message} | ConvertTo-Json -Compress))
        }
        if ($timer.Elapsed.TotalSeconds -ge 5) { $events.Flush(); Save-CleanupState; $timer.Restart() }
    }
    $state.status='verified_regular_files_removed_pending_links_directories_and_temporary_git'
    $state.finished_at=[DateTime]::UtcNow.ToString('o'); Save-CleanupState
} finally { $events.Dispose() }
$state | ConvertTo-Json -Depth 5
