# RoboMaster 工作区（原210主机4TB盘）

主机：10.24.3.125，用户egde。磁盘UUID：AFEF50F71FC9187D。
工作区：/mnt/robowork4t/workspaces/robomaster。

- mjcf/：来自Windows本机C:/Users/lulu/Desktop/claude/mjcf，含Git仓库、资产、报告及模型文件。
- history/local_F/RMPOLAR-RL/：来自本机F:/RMPOLAR-RL的训练与归档目录；当前v4 CAD装配和工具链不在迁移范围。
- history/host210/mod4_windows_data/：原服务器/mnt/mod4_windows_data上的MOD4/H1/PEER_TLS/T3/LINUX历史训练与zy_ckpt。
- migration/：本次来源清单、分批SHA256、复制与后续校验状态。复制未验证前不删除源数据。

当前迁移仍在执行。一个本机旧解包目录因Windows权限及被取消的UAC无法读取，保留在源处，详见迁移记录。Windows平台虚拟环境和原绝对路径作为历史文件保留；迁移不等于训练或运行验证。

以前的实验、失败、检查点、once标记及原路径记录保持，不因存储迁移重新运行。
