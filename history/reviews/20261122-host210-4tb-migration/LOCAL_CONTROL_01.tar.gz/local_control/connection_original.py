from pathlib import Path
import sys,shlex,json
sys.path.insert(0,"F:/RMPOLAR-RL/mod4_standing_step200_rlbptt_20261103/scut_native_v36")
from host_access import load
ROOT=Path("F:/RMPOLAR-RL/mod4_standing_step200_rlbptt_20261103")
W=Path("C:/Users/lulu/Desktop/claude/mjcf")
def open_connection():
 wrapper=load("migration210_authorized",ROOT/"control/archived_connectors/same_authorized_session_compressed_transport_v227.py");wrapper.W=W
 transport,previous=wrapper.install()
 try:
  route=load("migration210_newip",ROOT/"control/archived_connectors/strict_user_forwarded_original210_transport_v1.py");route.W=W;route.HOST="10.24.3.125";route.PORT=22
  client=route.connect()
  from reuse_authorized_session_transport import recover
  secret,_=recover("RM_SSH_PASSWORD")
  return client,lambda:setattr(transport,"SESSION",previous),secret
 except BaseException:
  transport.SESSION=previous
  raise

def run_python(code,sudo=False):
 client=None;restore=lambda:None;secret=None
 try:
  client,restore,secret=open_connection()
  cmd="/usr/bin/python3 -c "+shlex.quote(code)
  if sudo:cmd="sudo -S -p '' -- "+cmd
  stdin,out,err=client.exec_command(cmd,timeout=50)
  if sudo:
   stdin.write(secret+"\n");stdin.flush();stdin.channel.shutdown_write()
  output=out.read().decode(errors="replace");error=err.read().decode(errors="replace");rc=out.channel.recv_exit_status()
  if rc:raise RuntimeError("remote rc="+str(rc)+" "+error+" "+output)
  return output
 finally:
  secret=None
  if client is not None:client.close()
  restore()
