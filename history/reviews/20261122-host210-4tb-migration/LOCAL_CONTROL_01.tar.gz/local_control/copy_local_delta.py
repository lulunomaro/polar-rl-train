from pathlib import Path
import os,sys,json,datetime,hashlib,tarfile,shlex,threading,traceback,argparse
from connection import open_connection
P=Path(__file__).resolve().parent;W='/mnt/robowork4t/workspaces/robomaster'
ap=argparse.ArgumentParser();ap.add_argument('--round',required=True);ap.add_argument('--scope',choices=['mjcf','all'],default='all');ap.add_argument('--tool-receipt-only',action='store_true');a=ap.parse_args()
label='local_delta_'+a.round;receipt=P/(label+'_verified.json');assert a.tool_receipt_only or not receipt.exists(),'Delta already verified; do not repeat'
state={'status':'inventory','round':a.round,'scope':a.scope,'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_removal_started':False,'changed_files':0,'changed_bytes':0}
def save():
 if not a.tool_receipt_only:(P/(label+'_state.json')).write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
base={}
for f in sorted([v for v in P.glob('*_manifest.json') if not v.name.startswith('local_delta_')])+sorted(P.glob('local_delta_*_manifest.json')):
 if a.scope=='mjcf' and f.name.startswith('F_training_'):continue
 if not (f.name.startswith('mjcf_') or f.name.startswith('F_training_') or f.name.startswith('local_delta_')):continue
 m=json.loads(f.read_text(encoding='utf-8'))
 if 'groups' in m:
  for group in m['groups']:
   for row in group['files']:base[(str(Path(group['source_root'])),row['path'])]=row
 else:
  for row in m['files']:base[(str(Path(m['source_root'])),row['path'])]=row
config=json.loads((P/'local_transfer_plan.json').read_text(encoding='utf-8'));groups=[];errors=[]
for name,root,dest,selected in [('mjcf',Path('C:/Users/lulu/Desktop/claude/mjcf'),W+'/mjcf',None),('F_training',Path('F:/RMPOLAR-RL'),W+'/history/local_F/RMPOLAR-RL',set(config['F_selected_top_levels']))]:
 if a.scope=='mjcf' and name!='mjcf':continue
 rows=[];stack=[root]
 while stack:
  d=stack.pop()
  try:
   entries=list(os.scandir(d))
  except OSError as e:errors.append({'path':str(d),'error':str(e)});continue
  for ent in entries:
   p=Path(ent.path);rel=p.relative_to(root).as_posix()
   if selected is not None and rel.split('/')[0] not in selected:continue
   try:
    st=ent.stat(follow_symlinks=False)
    if st.st_file_attributes&0x400:continue
    if st.st_file_attributes&0x10:stack.append(p);continue
    old=base.get((str(root),rel))
    if old and (old['bytes'],old['mtime_ns'])==(st.st_size,st.st_mtime_ns):continue
    row={'path':rel,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'sha256':sha(p)};after=p.stat();assert (st.st_size,st.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'Source changed while hashing '+str(p)
    rows.append(row)
   except OSError as e:errors.append({'path':str(p),'error':str(e)})
 if rows:groups.append({'source':name,'source_root':str(root),'destination':dest,'files':rows})
state.update(status='ready_to_copy',changed_files=sum(len(g['files']) for g in groups),changed_bytes=sum(r['bytes'] for g in groups for r in g['files']),source_access_errors=errors);save()
manifest={'groups':groups,'source_access_errors':errors};mf=P/(label+'_manifest.json')
if not a.tool_receipt_only:mf.write_text(json.dumps(manifest,ensure_ascii=False)+'\n',encoding='utf-8')
client=None
try:
 client,restore,secret=open_connection();secret=None
 for group in groups:
  state.update(status='copying',current_source=group['source']);save()
  i,o,e=client.exec_command('tar -xf - --no-same-owner --no-same-permissions -C '+shlex.quote(group['destination']),timeout=None)
  stderr=[]
  def drain():stderr.append(e.read().decode(errors='replace'))
  thread=threading.Thread(target=drain);thread.start()
  class Writer:
   def write(self,data):i.channel.sendall(data);return len(data)
   def flush(self):pass
  root=Path(group['source_root'])
  with tarfile.open(fileobj=Writer(),mode='w|',bufsize=1024**2,format=tarfile.PAX_FORMAT,encoding='utf8') as tar:
   for row in group['files']:tar.add(root/row['path'],arcname=row['path'],recursive=False)
  i.channel.shutdown_write();stdout=o.read().decode(errors='replace');rc=o.channel.recv_exit_status();thread.join();assert rc==0,(rc,''.join(stderr),stdout)
 remote_manifest=W+'/migration/'+mf.name
 if not a.tool_receipt_only:
  with client.open_sftp() as s:s.put(str(mf),remote_manifest)
 code="""from pathlib import Path
import json,hashlib,stat
m=Path(MANIFEST);x=json.loads(m.read_text());files=0;amount=0
for group in x['groups']:
 root=Path(group['destination']);resolved_root=root.resolve()
 for row in group['files']:
  p=root/row['path'];assert p.resolve().is_relative_to(resolved_root);info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size==row['bytes']
  with p.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256'],str(p)
  files+=1;amount+=row['bytes']
r={'status':'verified','content_sha256_verified':True,'files':files,'bytes':amount,'manifest':str(m),'final_disk_flush_pending':True};m.with_name(m.stem+'_verified.json').write_text(json.dumps(r,indent=2)+'\\n');print(json.dumps(r))
""".replace('MANIFEST',repr(remote_manifest))
 if a.tool_receipt_only:
  code=code.replace("m=Path("+repr(remote_manifest)+");x=json.loads(m.read_text());files=0;amount=0","import sys; x=json.load(sys.stdin);files=0;amount=0")
  code=code[:code.index("r={'status':'verified'")]+"print(json.dumps({'status':'verified','content_sha256_verified':True,'files':files,'bytes':amount,'receipt':'tool_output_only','final_disk_flush_pending':True}))\n"
 i,o,e=client.exec_command('/usr/bin/python3 -c '+shlex.quote(code),timeout=None)
 if a.tool_receipt_only:i.write(json.dumps(manifest,ensure_ascii=False));i.channel.shutdown_write()
 out=o.read().decode();err=e.read().decode();rc=o.channel.recv_exit_status();assert rc==0,(rc,err,out)
 result=json.loads(out)
 if not a.tool_receipt_only:receipt.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 state.update(status='verified_pending_flush',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),verified=result);save();print(json.dumps(result))
except BaseException as e:
 state.update(status='failed',error_type=type(e).__name__,error=str(e));save();traceback.print_exc();raise
finally:
 if client is not None:client.close()
