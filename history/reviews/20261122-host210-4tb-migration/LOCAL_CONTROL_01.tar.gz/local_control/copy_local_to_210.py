from pathlib import Path
import os,sys,json,subprocess,time,datetime
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from connection import open_connection
plan=json.loads((P/'local_transfer_plan.json').read_text(encoding='utf8'))
state={'status':'running','stages':[],'pid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources_removed':False}
def save():(P/'local_copy_state.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
c=None;secret=None
try:
 c,restore,secret=open_connection();c.close();c=None
 env=dict(os.environ,RM_MIGRATION_SSH_PASSWORD=secret);env['WSLENV']=env.get('WSLENV','')+':RM_MIGRATION_SSH_PASSWORD'
 common=['wsl.exe','-d','Ubuntu','--','env','SSH_ASKPASS=/mnt/c/Users/lulu/.codex/migrations/210_4tb_20261122/ssh_askpass.py','SSH_ASKPASS_REQUIRE=force','DISPLAY=migration','rsync']
 ssh='ssh -F /dev/null -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/mnt/c/Users/lulu/.ssh/known_hosts -o UpdateHostKeys=no -o PreferredAuthentications=password -o PubkeyAuthentication=no -o NumberOfPasswordPrompts=1 -o ConnectTimeout=10 -o ServerAliveInterval=15'
 for src in plan['sources']:
  state['current']=src['name'];save()
  args=common+['-rlt','--links','--partial','--partial-dir=.rsync-partial','--info=progress2','--stats','--no-owner','--no-group','--no-perms','--modify-window=1','-e',ssh]
  if src.get('files_from'):args+=['--files-from='+src['files_from']]
  args += [src['source'],src['destination']]
  with (P/(src['name']+'_copy.log')).open('ab') as output:
   proc=subprocess.Popen(args,stdout=output,stderr=subprocess.STDOUT,env=env);state['rsync_pid']=proc.pid;save();rc=proc.wait()
  state['stages'].append({'name':src['name'],'exit_code':rc,'log':src['name']+'_copy.log'});save()
  if rc not in (0,23,24):raise RuntimeError('rsync failed '+src['name']+' code '+str(rc))
 state['status']='copy_finished_pending_verification';state['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as e:
 state.update(status='failed',error_type=type(e).__name__,error=str(e));save();raise
finally:
 secret=None
 if c is not None:c.close()
