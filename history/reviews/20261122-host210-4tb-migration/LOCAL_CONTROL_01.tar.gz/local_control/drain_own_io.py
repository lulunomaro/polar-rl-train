from pathlib import Path
import os,signal,time,json,datetime
PID=45829;root='/mnt/robowork4t/workspaces/robomaster/migration';statefile=Path('/tmp/robowork_migration_io_drain_state.json')
assert os.getpgid(PID)==PID
assert root+'/copy_remote_history.py' in Path(f'/proc/{PID}/cmdline').read_bytes().decode(errors='replace')
state={'status':'pausing_only_own_copy_group','pid':os.getpid(),'copy_group':PID,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():statefile.write_text(json.dumps(state,indent=2)+'\n')
def syncs():
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   a=p.joinpath('cmdline').read_bytes().split(b'\0')
   if a and a[0].split(b'/')[-1]==b'sync' and b'/mnt/robowork4t/workspaces/robomaster/mjcf' in a:out.append(int(p.name))
  except (OSError,ProcessLookupError):pass
 return out
save();os.killpg(PID,signal.SIGSTOP)
try:
 start=time.monotonic()
 while time.monotonic()-start<180:
  active=syncs();state.update(status='waiting_old_syncs',sync_pids=active,seconds=round(time.monotonic()-start));save()
  if not active:break
  time.sleep(5)
finally:
 if Path(f'/proc/{PID}').exists():
  assert root+'/copy_remote_history.py' in Path(f'/proc/{PID}/cmdline').read_bytes().decode(errors='replace');os.killpg(PID,signal.SIGCONT)
 state.update(status='own_copy_resumed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
