from pathlib import Path
import os,json,gzip,time,stat,collections
CONTROL=Path(__file__).resolve().parent
roots=[Path('C:/Users/lulu/Desktop/claude/mjcf'),Path('F:/RMPOLAR-RL')]
all_summary=[];errors=[];links=[]
for root in roots:
 start=time.time();totals=collections.defaultdict(lambda:dict(files=0,bytes=0,directories=0));seen=0
 target=CONTROL/('inventory_'+('mjcf' if root.drive=='C:' else 'F_RMPOLAR')+'.jsonl.gz')
 assert not target.exists(),target
 with gzip.open(target,'wt',encoding='utf8') as report:
  stack=[root]
  while stack:
   directory=stack.pop()
   try:
    with os.scandir(directory) as it:
     for e in it:
      try:
       st=e.stat(follow_symlinks=False);path=Path(e.path);rel=path.relative_to(root).as_posix();top=rel.split('/')[0];isdir=bool(st.st_file_attributes&0x10)
       if st.st_file_attributes&0x400:
        value=dict(path=rel,kind='reparse',target=str(path.resolve()),bytes=st.st_size);links.append(dict(root=str(root),**value))
       elif isdir:
        totals[top]['directories']+=1;stack.append(path);value=dict(path=rel,kind='directory')
       else:
        totals[top]['files']+=1;totals[top]['bytes']+=st.st_size;value=dict(path=rel,kind='file',bytes=st.st_size,mtime_ns=st.st_mtime_ns)
       report.write(json.dumps(value,ensure_ascii=False)+'\n');seen+=1
      except OSError as exc:errors.append(dict(path=e.path,error=str(exc)))
   except OSError as exc:errors.append(dict(path=str(directory),error=str(exc)))
   if seen%10000<100:
    (CONTROL/'inventory_progress.json').write_text(json.dumps(dict(root=str(root),seen=seen,files=sum(v['files'] for v in totals.values()),bytes=sum(v['bytes'] for v in totals.values()),errors=len(errors))),encoding='utf8')
 summary=dict(root=str(root),files=sum(v['files'] for v in totals.values()),bytes=sum(v['bytes'] for v in totals.values()),directories=sum(v['directories'] for v in totals.values()),seconds=time.time()-start,top_levels=dict(totals))
 all_summary.append(summary);print(json.dumps({k:v for k,v in summary.items() if k!='top_levels'}),flush=True)
(CONTROL/'local_inventory_summary.json').write_text(json.dumps(dict(roots=all_summary,errors=errors,links=links),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(status='completed',errors=len(errors),links=len(links))),flush=True)
