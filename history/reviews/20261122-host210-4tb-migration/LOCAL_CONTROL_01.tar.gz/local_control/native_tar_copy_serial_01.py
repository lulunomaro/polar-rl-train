from pathlib import Path
import sys,os,json,gzip,time,hashlib,subprocess,threading,shlex,datetime,traceback,tarfile
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from connection import open_connection
config=json.loads((P/'local_transfer_plan.json').read_text(encoding='utf8'))
BASE='/mnt/robowork4t/workspaces/robomaster';REMOTE_META=BASE+'/migration/native_batches'
state={'status':'running','pid':os.getpid(),'verified_files':0,'verified_bytes':0,'batches':[],'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_removal_started':False}
def save():(P/'native_copy_state.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
def remote(client,code):
 _,o,e=client.exec_command('/usr/bin/python3 -c '+shlex.quote(code),timeout=None);out=o.read().decode();err=e.read().decode();rc=o.channel.recv_exit_status()
 if rc:raise RuntimeError('remote '+str(rc)+' '+err+' '+out)
 return out
sources=[]
for name,root,inventory,dest,selected in [('mjcf',Path('C:/Users/lulu/Desktop/claude/mjcf'),'inventory_mjcf.jsonl.gz',BASE+'/mjcf',None),('F_training',Path('F:/RMPOLAR-RL'),'inventory_F_RMPOLAR.jsonl.gz',BASE+'/history/local_F/RMPOLAR-RL',set(config['F_selected_top_levels']))]:
 rows=[]
 with gzip.open(P/inventory,'rt',encoding='utf8') as f:
  for line in f:
   row=json.loads(line)
   if selected is not None and row['path'].split('/')[0] not in selected:continue
   if row['kind']=='file':rows.append(row)
 sources.append((name,root,dest,rows))
state['expected_bytes']=sum(v['bytes'] for _,_,_,rows in sources for v in rows);state['expected_files']=sum(len(rows) for _,_,_,rows in sources);save()
client=None;secret=None
try:
 client,restore,secret=open_connection();secret=None
 remote(client,"from pathlib import Path;Path("+repr(REMOTE_META)+").mkdir(parents=True,exist_ok=True)")
 number=0
 for source,root,dest,rows in sources:
  groups=[];group=[];amount=0
  for row in rows:
   if group and (amount+row['bytes']>2*1024**3 or len(group)>=4000):groups.append(group);group=[];amount=0
   group.append(row);amount+=row['bytes']
  if group:groups.append(group)
  for group in groups:
   number+=1;label=f'{source}_{number:04d}';state.update(current_source=source,current_batch=label,phase='hash_source',current_batch_bytes=sum(v['bytes'] for v in group),hash_bytes=0);save()
   receipt=P/(label+'_verified.json')
   if receipt.exists():
    checked=json.loads(receipt.read_text());state['verified_files']+=checked['files'];state['verified_bytes']+=checked['bytes'];state['batches'].append(checked);save();continue
   manifest=[];last=time.monotonic()
   for row in group:
    path=root/row['path'];before=path.stat();h=hashlib.sha256()
    with path.open('rb') as f:
     while True:
      buf=f.read(4*1024**2)
      if not buf:break
      h.update(buf);state['hash_bytes']+=len(buf)
      if time.monotonic()-last>2:save();last=time.monotonic()
    after=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise RuntimeError('Source changed while hashing '+str(path))
    manifest.append(dict(path=row['path'],bytes=after.st_size,mtime_ns=after.st_mtime_ns,sha256=h.hexdigest()))
   mf=P/(label+'_manifest.json');mf.write_text(json.dumps({'source_root':str(root),'destination':dest,'files':manifest},ensure_ascii=False)+'\n',encoding='utf8')
   filelist=P/(label+'_files.bin');filelist.write_bytes(b''.join(v['path'].encode('utf8')+b'\0' for v in manifest))
   with client.open_sftp() as s:s.put(str(mf),REMOTE_META+'/'+mf.name)
   state.update(phase='transfer',streamed_bytes=0);save()
   i,o,e=client.exec_command('tar -xf - --no-same-owner --no-same-permissions -C '+shlex.quote(dest),timeout=None)
   errors=[]
   def drain():
    raw=e.read()
    if raw:errors.append(raw.decode(errors='replace'))
   reader=threading.Thread(target=drain);reader.start()
   class ChannelWriter:
    def write(self,data):
     i.channel.sendall(data);state['streamed_bytes']+=len(data)
     if time.monotonic()-self.last>2:save();self.last=time.monotonic()
     return len(data)
    def flush(self):pass
    last=time.monotonic()
   with tarfile.open(fileobj=ChannelWriter(),mode='w|',bufsize=1024**2,format=tarfile.PAX_FORMAT,encoding='utf8') as archive:
    for item in manifest:archive.add(root/item['path'],arcname=item['path'],recursive=False)
   local_rc=0
   i.channel.shutdown_write();stdout=o.read().decode(errors='replace');remote_rc=o.channel.recv_exit_status();reader.join()
   if local_rc or remote_rc:raise RuntimeError('tar failed '+label+' local '+str(local_rc)+' remote '+str(remote_rc)+' '+''.join(errors)+' '+stdout)
   state['phase']='verify_sha256';save()
   verify=r'''from pathlib import Path
import json,hashlib,subprocess
m=Path(MANIFEST);x=json.loads(m.read_text());root=Path(x['destination']);subprocess.run(['sync','-f',str(root)],check=True)
for row in x['files']:
 p=root/row['path'];assert p.resolve().is_relative_to(root.resolve()),p
 assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'],p
 with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 assert actual==row['sha256'],str(p)
result={'status':'verified','files':len(x['files']),'bytes':sum(v['bytes'] for v in x['files']),'manifest':str(m)}
m.with_name(m.stem+'_verified.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
   result=json.loads(remote(client,verify.replace('MANIFEST',repr(REMOTE_META+'/'+mf.name))))
   result.update(batch=label,source=source);receipt.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
   state['verified_files']+=result['files'];state['verified_bytes']+=result['bytes'];state['batches'].append(result);save()
 state.update(status='regular_files_verified_pending_directories_links_and_cleanup',phase='done',finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as exc:
 state.update(status='failed',error_type=type(exc).__name__,error=str(exc));save();traceback.print_exc();raise
finally:
 secret=None
 if client is not None:client.close()
