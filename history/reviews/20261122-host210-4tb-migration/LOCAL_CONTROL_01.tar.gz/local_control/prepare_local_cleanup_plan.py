from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parent
state=json.loads((P/'native_parallel_state.json').read_text())
receipts=sorted(P.glob('*_verified.json'))
selected=[];totals={'files':0,'bytes':0};seen=set()
for rp in receipts:
 if not (rp.name.startswith('mjcf_') or rp.name.startswith('F_training_')):continue
 receipt=json.loads(rp.read_text(encoding='utf-8-sig'));assert receipt['status']=='verified'
 legacy={'mjcf_0001_verified.json','mjcf_0002_verified.json','mjcf_0003_verified.json','mjcf_0007_verified.json'}
 assert receipt.get('content_sha256_verified') is True or rp.name in legacy
 label=rp.name.removesuffix('_verified.json');mf=P/(label+'_manifest.json');assert mf.is_file(),mf
 manifest=json.loads(mf.read_text(encoding='utf-8'));assert len(manifest['files'])==receipt['files']
 assert sum(r['bytes'] for r in manifest['files'])==receipt['bytes']
 for r in manifest['files']:
  pair=(manifest['source_root'],r['path']);assert pair not in seen,pair;seen.add(pair)
 totals['files']+=receipt['files'];totals['bytes']+=receipt['bytes']
 selected.append({'manifest':str(mf),'manifest_sha256':hashlib.sha256(mf.read_bytes()).hexdigest(),'receipt':str(rp),'files':receipt['files'],'bytes':receipt['bytes']})
all_done=totals['files']==367939 and totals['bytes']==140540752240 and all(v==0 for v in state.get('worker_exit_codes',{}).values())
plan={'status':'copied_all_pending_flush' if all_done else 'copy_in_progress_no_cleanup','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_roots':['C:/Users/lulu/Desktop/claude/mjcf','F:/RMPOLAR-RL'],'keep_evidence_checkout':'C:/Users/lulu/Desktop/claude/mjcf/polar-rl-train','unreadable_directory_retained':'C:/Users/lulu/Desktop/claude/mjcf/rmuc2026_work/unpack_verify_4zomhj13','totals':totals,'batches':selected,'source_deletion_authorized_by':'Human asked to move the selected workspace and training history','source_deletion_executed':False}
(P/'local_cleanup_plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':plan['status'],'totals':totals,'batches':len(selected)}))
