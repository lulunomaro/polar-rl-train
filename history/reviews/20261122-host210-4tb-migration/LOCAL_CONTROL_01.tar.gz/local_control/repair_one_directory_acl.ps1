$ErrorActionPreference = 'Stop'
$target = 'C:\Users\lulu\Desktop\claude\mjcf\rmuc2026_work\unpack_verify_4zomhj13'
$root = [System.IO.Path]::GetFullPath('C:\Users\lulu\Desktop\claude\mjcf')
$resolved = [System.IO.Path]::GetFullPath($target)
$control = 'C:\Users\lulu\.codex\migrations\210_4tb_20261122'
try {
 if (-not $resolved.StartsWith($root + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Outside intended workspace' }
 $item = Get-Item -LiteralPath $resolved -Force
 if ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { throw 'Unexpected reparse point' }
 & takeown.exe /F $resolved /R /D Y | Out-File -LiteralPath ($control + '\acl_repair_output.log') -Encoding utf8
 if ($LASTEXITCODE -ne 0) { throw 'Ownership repair failed' }
 & icacls.exe $resolved /grant:r '*S-1-5-21-2860478974-3886120496-2942276926-1001:(OI)(CI)F' /T /C | Out-File -LiteralPath ($control + '\acl_repair_output.log') -Append -Encoding utf8
 if ($LASTEXITCODE -ne 0) { throw 'ACL repair failed' }
 @{status='completed'; target=$resolved; entries=(Get-ChildItem -LiteralPath $resolved -Force).Count} | ConvertTo-Json | Set-Content -LiteralPath ($control + '\acl_repair_result.json') -Encoding utf8
} catch {
 @{status='failed'; target=$resolved; error=$_.Exception.Message} | ConvertTo-Json | Set-Content -LiteralPath ($control + '\acl_repair_result.json') -Encoding utf8
 exit 1
}