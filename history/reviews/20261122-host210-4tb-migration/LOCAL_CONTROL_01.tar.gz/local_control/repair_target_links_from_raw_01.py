
from pathlib import Path
import os,json,hashlib,datetime
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';plan=json.loads((D/'source_link_repair_plan_01.json').read_text());rows=[]
assert not (D/'source_link_repair_result_01.json').exists()
for r in plan:
 p=Path(r['destination']);assert p.is_relative_to(W) and p.parent.resolve().is_relative_to(W.resolve()) and p.is_symlink();old=os.readlink(p);desired=r['desired_target'];changed=old!=desired
 if changed:
  tmp=p.with_name(p.name+'.migration-link-tmp');assert not tmp.exists() and not tmp.is_symlink();os.symlink(desired,tmp);os.replace(tmp,p)
 actual=os.readlink(p);assert actual==desired or r['external_reference'] and actual.replace(chr(92),'/')==desired.replace(chr(92),'/')
 rows.append(dict(r,old_target=old,new_target=actual,rewritten=changed,new_target_sha256=hashlib.sha256(actual.encode()).hexdigest()))
for r in rows:r['new_target_present']=Path(r['destination']).exists()
unexpected=[r for r in rows if not r['external_reference'] and r['source_target_present'] and not r['new_target_present']]
out={'status':'raw_original_links_restored' if not unexpected else 'unexpected_missing_link_targets','rewritten':sum(r['rewritten'] for r in rows),'links':len(rows),'source_broken_links_preserved':sum(not r['source_target_present'] for r in rows),'external_original_references':sum(r['external_reference'] for r in rows),'unexpected_missing_targets':unexpected,'source_payload_modified':False,'rows':rows,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(D/'source_link_repair_result_01.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
