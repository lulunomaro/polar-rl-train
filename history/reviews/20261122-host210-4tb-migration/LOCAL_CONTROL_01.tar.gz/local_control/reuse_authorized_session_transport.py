"""Reuse only this task's previously used named MOD4 SSH environment value.

Do not print/store the value, inspect unrelated sessions, or replay old commands.
Only an explicit prior PowerShell assignment in this task's tool-call arguments
is accepted. The existing target transport still fixes the authorized host/user.
"""
from pathlib import Path
import json, os, re, runpy, sys

SESSION = Path('C:/Users/lulu/.codex/sessions/2026/09/07/rollout-2026-09-07T12-43-21-01a07a2d-9036-7531-a012-692df9f56353.jsonl')
W = Path(__file__).resolve().parent.parent
ALLOWED = {
    'read_actual': W/'MOD4_S3_E1_REVIEWED_STABLE_20261009/read_stable_actual.py',
    'read_plan_context': W/'RM2026_TERRAIN_AUDIT_20261009/read_annotation_context.py',
    'sync_clarification': W/'RM2026_TERRAIN_AUDIT_20261009/sync_curb_clarification_once.py',
    'read_evaluator': W/'RM2026_TERRAIN_AUDIT_20261009/read_current_evaluator.py',
}

def recover(name='RM_SSH_PASSWORD'):
    assert name in ('RM_SSH_PASSWORD','MOD4_EVAL_SSH_PASSWORD')
    pattern = re.compile(r"\$env:"+name+r"\s*=\s*'((?:[^']|'')*)'")
    value = None
    accepted = 0
    with SESSION.open(encoding='utf8') as f:
        for line in f:
            if name not in line:
                continue
            j = json.loads(line)
            payload = j.get('payload', {})
            item = payload.get('item', {})
            # Only actual historical tool inputs, not messages, outputs, or summaries.
            if item.get('type') == 'McpToolCall':
                if item.get('tool') not in ('exec','exec_command'):
                    continue
                args = item.get('arguments', {})
            elif payload.get('type') == 'custom_tool_call':
                if payload.get('name') != 'exec':
                    continue
                args = payload.get('input', '')
            elif payload.get('type') == 'function_call':
                if payload.get('name') not in ('functions.exec','exec_command','functions.exec_command'):
                    continue
                args = payload.get('arguments', '')
            else:
                continue
            text = json.dumps(args, ensure_ascii=False) if not isinstance(args,str) else args
            if 'reuse_authorized_session_transport' in text or 'pattern = re.compile' in text:
                continue
            for m in pattern.finditer(text):
                candidate = m.group(1).replace("''", "'")
                if not candidate or '<' in candidate or '\n' in candidate or candidate in ('REDACTED','***'):
                    continue
                value = candidate
                accepted += 1
    return value, accepted

if __name__ == '__main__':
    action=sys.argv[1]
    assert action in {*ALLOWED, 'availability'}
    required=['RM_SSH_PASSWORD']+(['MOD4_EVAL_SSH_PASSWORD'] if action=='read_evaluator' else [])
    values={name:(recover(name) if not os.environ.get(name) else (os.environ[name],0)) for name in required}
    if action=='availability':
        value,count=values['RM_SSH_PASSWORD']
        print(json.dumps(dict(previous_authorized_task_value_available=bool(value),explicit_tool_assignment_count=count)))
        sys.exit(0)
    if not all(value for value,count in values.values()):
        print(json.dumps(dict(pending=True,reason='No existing authorized task credential is available',remote_writes=0)))
        sys.exit(2)
    for name,(value,count) in values.items():os.environ[name]=value
    try:
        runpy.run_path(str(ALLOWED[action]),run_name='__main__')
    finally:
        for name in values:os.environ.pop(name,None)
