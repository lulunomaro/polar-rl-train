from pathlib import Path
import sys,os,subprocess,json,time,datetime
P=Path(__file__).resolve().parent
procs=[]
for shard in range(4):
 env=dict(os.environ,MIGRATION_SHARD=str(shard),MIGRATION_SHARDS='4',MIGRATION_MIN_BATCH='8')
 log=(P/f'native_worker_shard{shard}.log').open('ab')
 proc=subprocess.Popen([sys.executable,str(P/'native_tar_copy.py')],stdout=log,stderr=subprocess.STDOUT,env=env,creationflags=0x08000000);procs.append((shard,proc,log))
state={'status':'running','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'shards':[{'id':i,'pid':p.pid} for i,p,_ in procs],'source_removal_started':False,'expected_files':367939,'expected_bytes':140540752240}
while True:
 state['worker_exit_codes']={str(i):p.poll() for i,p,_ in procs};verified=[]
 for f in P.glob('*_verified.json'):
  try:
   x=json.loads(f.read_text(encoding='utf8'))
   if 'batch' in x:verified.append(x)
  except (OSError,json.JSONDecodeError):pass
 state.update(verified_files=sum(v['files'] for v in verified),verified_bytes=sum(v['bytes'] for v in verified),verified_batches=len(verified),checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 done=all(p.poll() is not None for _,p,_ in procs)
 if done:state['status']=('regular_files_verified_pending_cleanup' if state['verified_files']==state['expected_files'] else 'workers_done_pending_saved_batch_recovery') if all(p.returncode==0 for _,p,_ in procs) else 'failed_workers_preserved'
 out=P/'native_parallel_state.json';temp=out.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2)+'\n',encoding='utf8');temp.replace(out)
 if done:break
 time.sleep(5)
for _,_,f in procs:f.close()
print(json.dumps(state),flush=True)
