#!/usr/bin/python3
import os,sys
sys.stdout.write(os.environ["RM_MIGRATION_SSH_PASSWORD"]+"\n")
