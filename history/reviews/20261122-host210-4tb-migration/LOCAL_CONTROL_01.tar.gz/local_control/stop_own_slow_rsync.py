from pathlib import Path
import os,signal,json
found=[]
for q in Path('/proc').iterdir():
 if not q.name.isdigit():continue
 try:
  args=q.joinpath('cmdline').read_bytes().split(b'\0')
  if args and args[0].split(b'/')[-1]==b'rsync' and b'/mnt/c/Users/lulu/Desktop/claude/mjcf/' in args and b'egde@10.24.3.125:/mnt/robowork4t/workspaces/robomaster/mjcf/' in args:found.append(int(q.name))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert len(found)<=1,found
for pid in found:os.kill(pid,signal.SIGTERM)
print(json.dumps({'stopped_only_own_slow_copy':found,'source_removed':False}))
