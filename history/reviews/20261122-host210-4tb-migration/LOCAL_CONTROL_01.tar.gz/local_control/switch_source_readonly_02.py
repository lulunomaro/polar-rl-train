from pathlib import Path
import subprocess,json,os,datetime,hashlib,traceback
D=Path('/mnt/robowork4t/workspaces/robomaster/migration')
S='/mnt/mod4_windows_data';DEV='/dev/nvme0n1p5';UUID='EF3105C85DD986BD'
state={'attempt':'source-readonly-driver-02','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'preflight','commands':[],'source_mutation':False}
def save():
 (D/'source_readonly_driver_state_02.json').write_text(json.dumps(state,indent=2)+'\n')
def command(args,timeout=45):
 p=subprocess.run(args,text=True,capture_output=True,timeout=timeout)
 r={'command':args,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr};state['commands'].append(r);save();return r
try:
 mounts=json.loads(subprocess.check_output(['findmnt','-J','-T',S],text=True))['filesystems']
 actual=[m for m in mounts if m['target']==S and m['fstype']=='ntfs3' and os.path.realpath(m['source'])==DEV]
 assert len(actual)==1,mounts
 assert subprocess.check_output(['blkid','-s','UUID','-o','value',DEV],text=True).strip()==UUID
 state['original_mount']=actual[0];state['all_mounts_before']=mounts
 busy=[]
 for ent in Path('/proc').iterdir():
  if not ent.name.isdigit():continue
  try:
   links=[ent/'cwd',ent/'root',*list((ent/'fd').iterdir())]
   for link in links:
    try:
     dst=os.readlink(link)
     if dst==S or dst.startswith(S+'/'):busy.append({'pid':int(ent.name),'path':str(link),'destination':dst})
    except OSError:pass
  except (FileNotFoundError,PermissionError):pass
 state['source_users']=busy;assert not busy,busy;save()
 r=command(['umount',S]);assert r['returncode']==0,r
 r=command(['systemctl','stop','mnt-mod4_windows_data.automount']);assert r['returncode']==0,r
 state['status']='normally_unmounted';save()
 r=command(['ntfsinfo','-m',DEV],timeout=30);state['unmounted_metadata_inspection']=r;save()
 r=command(['mount','-t','ntfs-3g','-o','ro,nosuid,nodev,uid=1000,gid=1000','/dev/disk/by-uuid/'+UUID,S]);state['readonly_mount_returncode']=r['returncode'];save()
 if r['returncode']:
  state['status']='readonly_driver_mount_failed_original_restored'
  r=command(['systemctl','start','mnt-mod4_windows_data.automount']);assert r['returncode']==0,r
  r=command(['mount',S]);assert r['returncode']==0,r
 else:
  mounts=json.loads(subprocess.check_output(['findmnt','-J','-T',S],text=True))['filesystems']
  actual=[m for m in mounts if m['target']==S and m['fstype']=='fuseblk']
  assert len(actual)==1 and 'ro' in actual[0]['options'].split(','),mounts
  failed=json.loads((D/'source_read_error_paths.json').read_text());results=[]
  for name in failed:
   p=Path(name)
   try:
    with p.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    results.append({'path':name,'bytes':p.stat().st_size,'sha256':sha,'status':'read_ok'})
   except OSError as e:results.append({'path':name,'status':'read_error','error':str(e)})
  state['read_results']=results;state['status']='readonly_driver_read_complete';save()
 state['mounts_after']=json.loads(subprocess.check_output(['findmnt','-J','-T',S],text=True))['filesystems']
 state['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as e:
 state.update(status='failed',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());save()
print(json.dumps(state,indent=2))
