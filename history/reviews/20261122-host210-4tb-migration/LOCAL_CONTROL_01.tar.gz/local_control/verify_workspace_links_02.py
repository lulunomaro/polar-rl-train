
from pathlib import Path
import json,os,datetime
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';x=json.loads((D/'structure_plan.json').read_text());rows=[]
for r in x['links']:
 p=Path(r['destination']);external=not bool(r['mapped_target']);expected=os.path.relpath(r['mapped_target'],p.parent) if not external else r['original_target'];assert p.is_symlink();actual=os.readlink(p)
 assert actual==expected or external and actual.replace(chr(92),'/')==expected.replace(chr(92),'/'),str(p)
 rows.append({'path':str(p),'link':actual,'external_original_reference':external,'driver_normalized_windows_separators':actual!=expected,'target_present':p.exists()})
workspace=json.loads((W/'robomaster.code-workspace').read_text());assert len(workspace['folders'])==4
out={'status':'mapped_links_and_workspace_definition_verified','links':len(rows),'external_original_links':sum(r['external_original_reference'] for r in rows),'missing_internal_links':[r for r in rows if not r['external_original_reference'] and not r['target_present']],'rows':rows,'workspace_folders':workspace['folders'],'source_payload_modified':False,'reader_recovery_for':'01 strict external string check; NTFS3 returned Windows separators as forward slashes','at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(D/'workspace_structure_readback_02.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['rows','workspace_folders']},indent=2))
