from pathlib import Path
import os,json,stat,datetime
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';S=Path('/mnt/mod4_windows_data')
old=json.loads((D/'host210_inventory_before_02.json').read_text())['rows'];expected={r['path']:r for r in old};names=json.loads((D/'host210_source_inventory.json').read_text())['selected'];actual={}
for name in names:
 stack=[S/name]
 while stack:
  p=stack.pop();info=p.lstat();rel=str(p.relative_to(S))
  if stat.S_ISDIR(info.st_mode):
   actual[rel]={'path':rel,'type':'directory'};stack.extend(p.iterdir())
  elif stat.S_ISLNK(info.st_mode):actual[rel]={'path':rel,'type':'link','target':os.readlink(p)}
  elif stat.S_ISREG(info.st_mode):actual[rel]={'path':rel,'type':'file','bytes':info.st_size,'mtime_ns':info.st_mtime_ns}
  else:raise RuntimeError('Unexpected source object '+str(p))
known_links={r['path']:r['source_link'] for r in json.loads((D/'source_restore_links_state_05.json').read_text())['links']}
changes=[]
for rel,row in actual.items():
 before=expected.get(rel)
 if before is None:changes.append(dict(row,change='new'))
 elif row['type']!=before['type']:changes.append(dict(row,change='type_changed'))
 elif row['type']=='file' and (row['bytes'],row['mtime_ns'])!=(before['bytes'],before['mtime_ns']):changes.append(dict(row,change='content_metadata_changed'))
 elif row['type']=='link' and row['target']!=known_links.get(rel,before['target']):changes.append(dict(row,change='link_target_changed'))
removed=[rel for rel in expected if rel not in actual]
r={'status':'source_metadata_unchanged_since_readonly_verification' if not changes and not removed else 'source_delta_required_before_cleanup','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'regular_files':sum(v['type']=='file' for v in actual.values()),'regular_bytes':sum(v.get('bytes',0) for v in actual.values()),'changes':changes,'removed_paths':removed,'link_reader_differences_checked_separately':'source_restore_links_state_05.json','source_mutation':False};(D/'host210_source_freshness_01.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
