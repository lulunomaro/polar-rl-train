from pathlib import Path
import os,json,stat,datetime,hashlib,traceback,subprocess,time
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';S=Path('/mnt/mod4_windows_data');T=W/'history/host210/mod4_windows_data'
state={'status':'preflight','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed_files':0,'removed_bytes':0,'removed_links':0,'removed_directories':0,'compatibility_links':0,'retained':[],'source_removal_started':False}
def save():(D/'host210_cleanup_state.json').write_text(json.dumps(state,indent=2)+'\n')
def source_path(rel):
 rel=Path(rel);assert not rel.is_absolute() and '..' not in rel.parts and rel.parts
 p=S/rel;assert p.parent.resolve().is_relative_to(S.resolve()),p;return p
save()
try:
 proof=json.loads((D/'host210_composite_verification_05.json').read_text());assert proof['status']=='all_selected_history_content_verified'
 flush=json.loads((D/'target_final_flush_receipt.json').read_text());assert flush['status']=='completed' and flush['returncode']==0
 assert subprocess.check_output(['blkid','-s','UUID','-o','value','/dev/nvme0n1p5'],text=True).strip()=='EF3105C85DD986BD'
 assert subprocess.check_output(['blkid','-s','UUID','-o','value','/dev/sda3'],text=True).strip()=='AFEF50F71FC9187D'
 actual=json.loads(subprocess.check_output(['findmnt','-J','-T',str(S)],text=True))['filesystems'];assert any(m['fstype']=='ntfs3' and m['source']=='/dev/nvme0n1p5' and 'rw' in m['options'].split(',') for m in actual)
 busy=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  try:
   for link in [proc/'cwd',proc/'root',*list((proc/'fd').iterdir())]:
    try:
     target=os.readlink(link)
     if target==str(S) or target.startswith(str(S)+'/'):busy.append({'pid':int(proc.name),'path':str(link),'target':target})
    except OSError:pass
  except (PermissionError,FileNotFoundError):pass
 state['source_users']=busy;assert not busy,busy
 state.update(status='removing_verified_regular_files',source_removal_started=True);save()
 digest=hashlib.sha256();last=time.monotonic()
 with (D/'host210_verified_files_02.jsonl').open() as f:
  for line in f:
   row=json.loads(line)
   if row['type']!='file':continue
   p=source_path(row['path'])
   try:
    info=p.lstat();assert stat.S_ISREG(info.st_mode) and (info.st_size,info.st_mtime_ns)==(row['bytes'],row['mtime_ns']),'Source changed after full verification'
    p.unlink();state['removed_files']+=1;state['removed_bytes']+=row['bytes'];digest.update((row['path']+'\0'+row['sha256']+'\n').encode())
   except Exception as e:state['retained'].append({'path':str(p),'reason':str(e),'type':type(e).__name__})
   if time.monotonic()-last>5:state['removed_manifest_digest_so_far']=digest.hexdigest();save();last=time.monotonic()
 recovered=json.loads((D/'training_log_recovery_state_04.json').read_text());assert recovered['status']=='all_requested_logs_recovered' and len(recovered['files'])==61
 for row in recovered['files']:
  p=source_path(row['path']);dst=T/row['path']
  try:
   info=p.lstat();assert stat.S_ISREG(info.st_mode) and (info.st_size,info.st_mtime_ns)==(row['bytes'],row['source_mtime_ns']),'Recovered source changed'
   with dst.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']
   p.unlink();state['removed_files']+=1;state['removed_bytes']+=row['bytes'];digest.update((row['path']+'\0'+row['sha256']+'\n').encode())
  except Exception as e:state['retained'].append({'path':str(p),'reason':str(e),'type':type(e).__name__})
 mapping=json.loads((D/'filename_mapping_recovery_01.json').read_text());p=source_path(mapping['source_relative']);dst=T/mapping['target_relative']
 try:
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and (info.st_size,info.st_mtime_ns)==(mapping['bytes'],mapping['source_mtime_ns'])
  with dst.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==mapping['sha256']
  p.unlink();state['removed_files']+=1;state['removed_bytes']+=mapping['bytes'];digest.update((mapping['source_relative']+'\0'+mapping['sha256']+'\n').encode())
 except Exception as e:state['retained'].append({'path':str(p),'reason':str(e),'type':type(e).__name__})
 state['removed_manifest_sha256']=digest.hexdigest();state['status']='removing_verified_links_and_empty_directories';save()
 inventory=json.loads((D/'host210_inventory_before_02.json').read_text())['rows']
 for row in inventory:
  if row['type']!='link':continue
  p=source_path(row['path']);dst=T/row['path']
  try:
   assert p.is_symlink() and dst.is_symlink() and os.readlink(p)==os.readlink(dst)
   p.unlink();state['removed_links']+=1
  except Exception as e:state['retained'].append({'path':str(p),'reason':str(e),'type':type(e).__name__})
 for row in sorted([r for r in inventory if r['type']=='directory'],key=lambda x:len(Path(x['path']).parts),reverse=True):
  p=source_path(row['path'])
  try:p.rmdir();state['removed_directories']+=1
  except OSError as e:
   if e.errno not in [2,39]:state['retained'].append({'path':str(p),'reason':str(e),'type':type(e).__name__})
 names=json.loads((D/'host210_source_inventory.json').read_text())['selected']
 for name in names:
  p=S/name;dst=T/name
  if not p.exists() and not p.is_symlink():
   assert dst.exists() or dst.is_symlink();os.symlink(str(dst),p);state['compatibility_links']+=1
  else:state['retained'].append({'path':str(p),'reason':'Original selected root still occupied; compatibility link not substituted'})
 state.update(status='moved_with_legacy_path_links' if not state['retained'] else 'verified_sources_moved_with_retained_exceptions',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(status='failed',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());save();raise
print(json.dumps(state,indent=2))
