from pathlib import Path
import os,json,subprocess,time,datetime
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';SOURCE=Path('/mnt/mod4_windows_data');DEST=W/'history/host210/mod4_windows_data';DEST.mkdir(parents=True,exist_ok=True)
assert SOURCE.is_mount() and Path('/mnt/robowork4t').is_mount()
selected=sorted(v.name for v in SOURCE.iterdir() if v.name.startswith(('MOD4','mod4','H1','PEER_TLS','T3_','LINUX_')) or v.name=='zy_ckpt')
assert selected
names=D/'host210_selected_top.txt';names.write_text('\n'.join(selected)+'\n')
state={'status':'inventory','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(SOURCE),'destination':str(DEST),'selected_top_count':len(selected),'source_removal_started':False}
def save():(D/'host210_copy_state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 sizes=subprocess.run(['du','-sb','--count-links',*[str(SOURCE/v) for v in selected]],capture_output=True,text=True,timeout=180)
 rows=[]
 for line in sizes.stdout.splitlines():
  n,path=line.split('\t',1);rows.append({'source':path,'bytes':int(n)})
 (D/'host210_source_inventory.json').write_text(json.dumps({'sources':rows,'du_exit':sizes.returncode,'errors':sizes.stderr,'selected':selected},indent=2)+'\n')
 state.update(status='copying',expected_bytes=sum(v['bytes'] for v in rows),inventory_exit=sizes.returncode);save()
 args=['nice','-n','10','ionice','-c','2','-n','7','rsync','-rlt','--links','--partial','--partial-dir=.rsync-partial','--no-owner','--no-group','--no-perms','--info=progress2','--stats','--files-from='+str(names),str(SOURCE)+'/',str(DEST)+'/']
 with (D/'host210_copy.log').open('ab') as log:proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);state['rsync_pid']=proc.pid;save();rc=proc.wait()
 state.update(status='copy_finished_pending_verification' if rc==0 else 'copy_finished_with_errors',rsync_exit=rc,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(status='failed',error_type=type(e).__name__,error=str(e));save();raise
