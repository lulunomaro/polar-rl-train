from pathlib import Path
import os,json,datetime
D=Path('/mnt/robowork4t/workspaces/robomaster/migration');x=json.loads((D/'structure_plan.json').read_text());state={'status':'running','directories':0,'links':0,'external_link_targets':[]}
def save():(D/'structure_state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 root=Path('/mnt/robowork4t/workspaces/robomaster')
 for value in x['directories']:
  p=Path(value);assert p.is_relative_to(root);p.mkdir(parents=True,exist_ok=True);state['directories']+=1
  if state['directories']%1000==0:save()
 for row in x['links']:
  p=Path(row['destination']);assert p.is_relative_to(root);p.parent.mkdir(parents=True,exist_ok=True)
  target=os.path.relpath(row['mapped_target'],p.parent) if row['mapped_target'] else row['original_target']
  if p.is_symlink():p.unlink()
  elif p.exists():raise RuntimeError('Unexpected occupied link '+str(p))
  os.symlink(target,p)
  if not row['mapped_target']:state['external_link_targets'].append(row)
  state['links']+=1
 state.update(status='completed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(status='failed',error_type=type(e).__name__,error=str(e));save();raise
