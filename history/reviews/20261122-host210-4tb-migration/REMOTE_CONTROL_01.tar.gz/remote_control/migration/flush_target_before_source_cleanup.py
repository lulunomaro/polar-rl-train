from pathlib import Path
import os,json,datetime,subprocess
D=Path('/mnt/robowork4t/workspaces/robomaster/migration');receipt=D/'target_final_flush_receipt.json';assert not receipt.exists()
assert json.loads((D/'native_local_copy_complete.json').read_text())['status']=='all_native_original_files_verified'
assert json.loads((D/'local_delta_03_manifest_verified.json').read_text())['status']=='verified'
assert json.loads((D/'host210_composite_verification_05.json').read_text())['status']=='all_selected_history_content_verified'
assert json.loads((D/'source_link_repair_result_01.json').read_text())['status']=='raw_original_links_restored'
state={'status':'running','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':['sync','-f','/mnt/robowork4t'],'source_removal_started':False}
receipt.write_text(json.dumps(state,indent=2)+'\n')
p=subprocess.run(state['command'],capture_output=True,text=True)
state.update(status='completed' if p.returncode==0 else 'failed',returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());receipt.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state))
