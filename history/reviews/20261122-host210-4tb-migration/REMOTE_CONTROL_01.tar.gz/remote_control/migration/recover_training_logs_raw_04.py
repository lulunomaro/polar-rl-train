from pathlib import Path
import subprocess,json,re,os,hashlib,struct,datetime,traceback
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';S=Path('/mnt/mod4_windows_data');T=W/'history/host210/mod4_windows_data';DEV=Path('/dev/nvme0n1p5')
OUT=D/'training_log_readonly_recovery_04';OUT.mkdir(exist_ok=True)
state={'attempt':'training-log-readonly-recovery-04','pid':os.getpid(),'status':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_modified':False,'method':'ntfsinfo on read-only mounted source plus O_RDONLY block reads; accept only full TFRecord length/data CRC32C validation','files':[]}
def save():(D/'training_log_recovery_state_04.json').write_text(json.dumps(state,indent=2)+'\n')
table=[]
for n in range(256):
 c=n
 for _ in range(8):c=(c>>1)^(0x82F63B78 if c&1 else 0)
 table.append(c)
def crc(data):
 c=0xffffffff
 for b in data:c=table[(c^b)&255]^(c>>8)
 return c^0xffffffff
def masked(data):
 c=crc(data);return (((c>>15)|(c<<17))+0xa282ead8)&0xffffffff
assert crc(b'123456789')==0xe3069283

def validate(data):
 pos=0;count=0
 while pos<len(data):
  assert pos+12<=len(data),'Incomplete TFRecord header at '+str(pos)
  n=struct.unpack_from('<Q',data,pos)[0];assert n<=len(data),'Invalid TFRecord length'
  assert masked(data[pos:pos+8])==struct.unpack_from('<I',data,pos+8)[0],'TFRecord length CRC mismatch at '+str(pos)
  end=pos+12+n;assert end+4<=len(data),'Incomplete TFRecord body'
  assert masked(data[pos+12:end])==struct.unpack_from('<I',data,end)[0],'TFRecord payload CRC mismatch at '+str(pos)
  pos=end+4;count+=1
 assert count>0
 return count
save()
try:
 mounts=json.loads(subprocess.check_output(['findmnt','-J','-T',str(S)],text=True))['filesystems']
 assert len(mounts)==1 and mounts[0]['fstype']=='fuseblk' and 'ro' in mounts[0]['options'].split(','),mounts
 assert subprocess.check_output(['blkid','-s','UUID','-o','value',str(DEV)],text=True).strip()=='EF3105C85DD986BD'
 v=subprocess.run(['ntfsinfo','-f','-m',str(DEV)],capture_output=True,text=True,check=True)
 (OUT/'volume_metadata.txt').write_text(v.stdout+v.stderr)
 cluster=int(re.search(r'Cluster Size:\s+(\d+)',v.stdout).group(1));assert cluster==4096
 volume_size=int(subprocess.check_output(['blockdev','--getsize64',str(DEV)],text=True).strip())
 failed=json.loads((D/'source_read_error_paths.json').read_text())
 limit=int(os.environ.get('MIGRATION_RECOVER_LOG_LIMIT','61'));assert 0<limit<=61
 with DEV.open('rb',buffering=0) as disk:
  for idx,name in enumerate(failed[:limit]):
   rel=Path(name).relative_to(S);src=S/rel;before=src.stat();row={'path':str(rel),'bytes':before.st_size,'source_mtime_ns':before.st_mtime_ns,'source_retained':True}
   try:
    p=subprocess.run(['ntfsinfo','-f','-v','-F','/'+str(rel),str(DEV)],capture_output=True,text=True,timeout=30)
    (OUT/f'{idx:03d}_ntfsinfo.txt').write_text(p.stdout+p.stderr)
    assert p.returncode==0,'ntfsinfo failed'
    sections=re.split(r'(?=Dumping attribute )',p.stdout);runs=[];sizes=[];flags=[]
    for section in sections:
     if not section.startswith('Dumping attribute $DATA (0x80)'):continue
     assert re.search(r'Name length:\s+0 ',section),'Named DATA attribute is outside this recovery'
     assert re.search(r'Resident:\s+No',section),'Expected nonresident log'
     flags.append(re.search(r'Attribute flags:\s+(0x[0-9a-fA-F]+)',section).group(1))
     for key in ['Data size','Initialized size']:
      m=re.search(key+r':\s+(\d+)',section)
      if m:sizes.append(int(m.group(1)))
     for m in re.finditer(r'^\s*(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s*$',section,re.M):runs.append(tuple(int(x,16) for x in m.groups()))
    assert sizes and all(n==before.st_size for n in sizes),'File data/initialized size mismatch'
    runs.sort();end=0;parts=[]
    for vcn,lcn,length in runs:
     assert vcn==end and length>0,'Incomplete or overlapping extents'
     assert (lcn+length)*cluster<=volume_size,'Extent outside source partition'
     disk.seek(lcn*cluster);data=disk.read(length*cluster);assert len(data)==length*cluster
     parts.append(data);end+=length
    assert end*cluster>=before.st_size and end*cluster-before.st_size<cluster
    data=b''.join(parts)[:before.st_size];records=validate(data);sha=hashlib.sha256(data).hexdigest()
    after=src.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'Source metadata changed'
    candidate=OUT/f'{idx:03d}_full_crc_verified.tfevents';candidate.write_bytes(data)
    with candidate.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==sha
    dst=T/rel;dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
     with dst.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==sha,'Existing target differs; retained original'
    else:
     candidate.replace(dst);os.utime(dst,ns=(before.st_atime_ns,before.st_mtime_ns))
    row.update(status='recovered_all_tfrecord_crc_verified',sha256=sha,records=records,data_attribute_flags=flags,extents=len(runs),target=str(dst),target_file_sha256_verified=True)
   except Exception as e:row.update(status='not_recovered',error_type=type(e).__name__,error=str(e))
   state['files'].append(row);save()
 state['status']='all_requested_logs_recovered' if all(r['status']=='recovered_all_tfrecord_crc_verified' for r in state['files']) else 'some_logs_unresolved'
 state['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as e:
 state.update(status='failed',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());save()
print(json.dumps(state,indent=2))
