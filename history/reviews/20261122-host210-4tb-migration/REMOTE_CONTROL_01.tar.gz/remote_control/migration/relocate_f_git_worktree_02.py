from pathlib import Path
import json,hashlib,subprocess,datetime
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';R=W/'history/local_F/RMPOLAR-RL';main=R/'repo-lqr';worktree=R/'repo-lqr-robust'
assert json.loads((D/'git_worktree_scoped_copy_complete_01.json').read_text())['status']=='all_selected_git_files_copied'
changes=[]
for p,original,new in [(worktree/'.git',b'gitdir: F:/RMPOLAR-RL/repo-lqr/.git/worktrees/repo-lqr-robust\n',('gitdir: '+str(main/'.git/worktrees/repo-lqr-robust')+'\n').encode()),(main/'.git/worktrees/repo-lqr-robust/gitdir',b'F:/RMPOLAR-RL/repo-lqr-robust/.git\n',(str(worktree/'.git')+'\n').encode())]:
 old=p.read_bytes();assert old.replace(b'\r\n',b'\n')==original,(str(p),old)
 p.write_bytes(new);assert p.read_bytes()==new
 changes.append({'path':str(p),'source_text':old.decode(),'source_bytes':len(old),'source_sha256':hashlib.sha256(old).hexdigest(),'relocated_text':new.decode(),'relocated_bytes':len(new),'relocated_sha256':hashlib.sha256(new).hexdigest(),'reason':'Windows absolute Git worktree administration pointer relocated to corresponding Linux workspace; branch and commit unchanged'})
heads={}
for p,expected in [(main,'85f548d4384e37cd9dd42c104ab7170adaf8ae3c'),(worktree,'375a2d965f3e0e409ad5fe99829df2c261a6c198')]:
 head=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip();assert head==expected;heads[str(p)]=head
out={'status':'worktree_paths_relocated_and_heads_preserved','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changes':changes,'heads':heads};(D/'git_worktree_relocation_01.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
