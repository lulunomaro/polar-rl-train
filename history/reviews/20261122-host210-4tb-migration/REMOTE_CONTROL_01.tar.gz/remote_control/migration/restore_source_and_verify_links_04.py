from pathlib import Path
import subprocess,os,json,datetime,stat,traceback,hashlib
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';S=Path('/mnt/mod4_windows_data');T=W/'history/host210/mod4_windows_data';DEV='/dev/nvme0n1p5'
state={'attempt':'source-driver-and-link-verification-04','status':'preflight','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'source_file_mutation':False}
def save():(D/'source_restore_links_state_04.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd):
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=45);r={'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr};state['commands'].append(r);save();assert p.returncode==0,r;return r
save()
try:
 v=json.loads((D/'host210_verify_state_02.json').read_text());assert 'finished_at' in v and v['source_metadata_unchanged'],v
 assert not Path('/proc') .joinpath(str(v['pid'])).exists(),'Content verifier still active'
 assert subprocess.check_output(['blkid','-s','UUID','-o','value',DEV],text=True).strip()=='EF3105C85DD986BD'
 mounts=json.loads(subprocess.check_output(['findmnt','-J','-T',str(S)],text=True))['filesystems'];assert len(mounts)==1 and mounts[0]['fstype']=='fuseblk' and 'ro' in mounts[0]['options'].split(',')
 busy=[]
 for ent in Path('/proc').iterdir():
  if not ent.name.isdigit():continue
  try:
   for link in [ent/'cwd',ent/'root',*list((ent/'fd').iterdir())]:
    try:
     dst=os.readlink(link)
     if dst==str(S) or dst.startswith(str(S)+'/'):busy.append({'pid':int(ent.name),'link':str(link),'target':dst})
    except OSError:pass
  except (FileNotFoundError,PermissionError):pass
 state['source_users']=busy;assert not busy,busy;save()
 run(['umount',str(S)])
 run(['systemctl','start','mnt-mod4_windows_data.automount'])
 os.stat(S)
 actual=json.loads(subprocess.check_output(['findmnt','-J','-T',str(S)],text=True))['filesystems']
 if not any(m['fstype']=='ntfs3' for m in actual):run(['mount',str(S)])
 actual=json.loads(subprocess.check_output(['findmnt','-J','-T',str(S)],text=True))['filesystems'];state['restored_mounts']=actual
 assert any(m['fstype']=='ntfs3' and os.path.realpath(m['source'])==DEV and 'rw' in m['options'].split(',') for m in actual),actual
 mapping=json.loads((D/'filename_mapping_recovery_01.json').read_text());assert mapping['status']=='content_verified_under_portable_filename'
 links=[];mapped_checked=0
 for failure in v['failed']:
  rel=Path(failure['path']);assert not rel.is_absolute() and '..' not in rel.parts
  if str(rel)==mapping['source_relative']:
   source_file=S/rel;target_file=T/mapping['target_relative'];assert source_file.stat().st_size==mapping['bytes']
   for check in [source_file,target_file]:
    with check.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==mapping['sha256']
   mapped_checked+=1;continue
  p=S/rel;q=T/rel;assert p.is_symlink() and q.is_symlink(),str(rel)
  source=os.readlink(p);target=os.readlink(q);assert source==target,(str(rel),source,target)
  links.append({'path':str(rel),'source_link':source,'target_link':target,'status':'verified_original_ntfs3_link'})
 recovered=json.loads((D/'training_log_recovery_state_04.json').read_text());assert recovered['status']=='all_requested_logs_recovered' and len(recovered['files'])==61
 assert mapped_checked==1
 assert v['verified_files']+62==v['source_files'],(v['verified_files'],v['source_files'])
 assert v['verified_bytes']+sum(r['bytes'] for r in recovered['files'])+mapping['bytes']==v['source_bytes']
 state.update(status='verified_against_original_ntfs3',links=links,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 composite={'status':'all_selected_history_content_verified','source':str(S),'destination':str(T),'regular_files':v['source_files'],'regular_bytes':v['source_bytes'],'sha256_source_target_files':v['verified_files'],'sha256_source_target_bytes':v['verified_bytes'],'readonly_extent_crc_recovered_files':61,'readonly_extent_crc_recovered_bytes':sum(r['bytes'] for r in recovered['files']),'links_verified_original_driver':len(links),'portable_filename_mapping_files':1,'portable_filename_mapping_bytes':mapping['bytes'],'portable_filename_mapping':mapping,'original_rsync_exit':23,'original_full_verifier_status':v['status'],'source_metadata_stable_during_full_verify':True,'original_failed_reports_preserved':True,'source_cleanup_pending':True,'target_final_flush_pending':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (D/'host210_composite_verification_04.json').write_text(json.dumps(composite,indent=2)+'\n')
except BaseException as e:state.update(status='failed',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());save();raise
print(json.dumps(state,indent=2))
