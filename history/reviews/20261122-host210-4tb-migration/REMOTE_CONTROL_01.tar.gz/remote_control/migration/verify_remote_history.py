from pathlib import Path
import os,hashlib,json,subprocess,datetime,time
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';S=Path('/mnt/mod4_windows_data');T=W/'history/host210/mod4_windows_data'
original=json.loads((D/'host210_copy_state.json').read_text());assert original.get('rsync_exit')==0 and original['status']=='copy_finished_pending_verification',original
names=json.loads((D/'host210_source_inventory.json').read_text())['selected']
state={'status':'snapshot_before_checksum','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_removal_started':False}
def save():(D/'host210_verify_state.json').write_text(json.dumps(state,indent=2)+'\n')
def snapshot():
 out=[]
 for name in names:
  root=S/name;digest=hashlib.sha256();count=0;size=0;stack=[root]
  while stack:
   p=stack.pop();st=p.lstat();rel=str(p.relative_to(S))
   if p.is_symlink():digest.update(json.dumps([rel,'link',os.readlink(p)],ensure_ascii=False).encode())
   elif p.is_dir():
    digest.update(json.dumps([rel,'directory'],ensure_ascii=False).encode());stack.extend(sorted(p.iterdir(),key=lambda v:v.name,reverse=True))
   else:
    count+=1;size+=st.st_size;digest.update(json.dumps([rel,'file',st.st_size,st.st_mtime_ns],ensure_ascii=False).encode())
  out.append({'name':name,'files':count,'bytes':size,'metadata_sha256':digest.hexdigest()})
 return out
save()
try:
 before=snapshot();(D/'host210_metadata_before.json').write_text(json.dumps(before,indent=2)+'\n');state.update(status='full_content_checksum',source_files=sum(v['files'] for v in before),source_bytes=sum(v['bytes'] for v in before));save()
 with (D/'host210_checksum_differences.log').open('wb') as out,(D/'host210_checksum_stderr.log').open('wb') as err:
  p=subprocess.Popen(['nice','-n','10','ionice','-c','2','-n','7','rsync','-rcni','--links','--no-owner','--no-group','--no-perms','--out-format=%i|%n%L','--files-from='+str(D/'host210_selected_top.txt'),str(S)+'/',str(T)+'/'],stdout=out,stderr=err);state['checksum_pid']=p.pid;save();rc=p.wait()
 differences=(D/'host210_checksum_differences.log').read_text();errors=(D/'host210_checksum_stderr.log').read_text();state['checksum_exit']=rc;state['difference_lines']=len(differences.splitlines());state['errors']=errors
 after=snapshot();(D/'host210_metadata_after.json').write_text(json.dumps(after,indent=2)+'\n');state['source_metadata_unchanged']=before==after
 state.update(status='verified_pending_source_cleanup' if rc==0 and not differences.strip() and before==after else 'verification_failed_sources_retained',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(status='failed',error_type=type(e).__name__,error=str(e));save();raise
