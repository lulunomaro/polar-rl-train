from pathlib import Path
import os,hashlib,json,subprocess,datetime,time,stat,traceback,concurrent.futures
W=Path('/mnt/robowork4t/workspaces/robomaster');D=W/'migration';S=Path('/mnt/mod4_windows_data');T=W/'history/host210/mod4_windows_data'
original=json.loads((D/'host210_copy_state.json').read_text());assert original['rsync_exit']==23 and original['status']=='copy_finished_with_errors'
read_attempt=json.loads((D/'source_readonly_driver_state_02.json').read_text());assert read_attempt['status']=='readonly_driver_read_complete'
excluded={str(Path(r['path']).relative_to(S)) for r in read_attempt['read_results'] if r['status']=='read_error'}
assert len(excluded)==61
names=json.loads((D/'host210_source_inventory.json').read_text())['selected']
state={'attempt':'host210-content-verification-02','status':'source_inventory','pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_removal_started':False,'original_copy_exit':23,'excluded_unreadable_files':61,'verified_files':0,'verified_bytes':0,'verified_links':0,'failed':[],'unreadable_sources_retained':True}
def save():(D/'host210_verify_state_02.json').write_text(json.dumps(state,indent=2)+'\n')
def inventory():
 rows=[];h=hashlib.sha256()
 for name in names:
  stack=[S/name]
  while stack:
   p=stack.pop();st=p.lstat();rel=str(p.relative_to(S))
   if stat.S_ISLNK(st.st_mode):r={'path':rel,'type':'link','target':os.readlink(p)}
   elif stat.S_ISDIR(st.st_mode):
    r={'path':rel,'type':'directory'};stack.extend(sorted(p.iterdir(),key=lambda x:x.name,reverse=True))
   elif stat.S_ISREG(st.st_mode):r={'path':rel,'type':'file','bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
   else:raise RuntimeError('Unexpected source object '+str(p))
   h.update(json.dumps(r,sort_keys=True,ensure_ascii=False).encode());h.update(b'\n');rows.append(r)
 return rows,h.hexdigest()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
save()
try:
 before,before_digest=inventory();state.update(status='sha256_source_target',source_inventory_sha256=before_digest,source_files=sum(r['type']=='file' for r in before),source_bytes=sum(r.get('bytes',0) for r in before),unreadable_bytes=sum(r.get('bytes',0) for r in before if r['path'] in excluded));save()
 (D/'host210_inventory_before_02.json').write_text(json.dumps({'metadata_sha256':before_digest,'rows':before},ensure_ascii=False)+'\n')
 last=time.monotonic()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool,(D/'host210_verified_files_02.jsonl').open('w',encoding='utf-8') as log:
  for row in before:
   rel=row['path'];src=S/rel;dst=T/rel
   if rel in excluded:continue
   state['current_path']=rel
   try:
    target=dst.lstat()
    if row['type']=='directory':assert stat.S_ISDIR(target.st_mode),str(dst)
    elif row['type']=='link':
     assert stat.S_ISLNK(target.st_mode) and os.readlink(dst)==row['target'],str(dst)
     state['verified_links']+=1;log.write(json.dumps(dict(row,status='verified'),ensure_ascii=False)+'\n')
    else:
     assert stat.S_ISREG(target.st_mode) and target.st_size==row['bytes'],str(dst)
     a=pool.submit(sha,src);b=pool.submit(sha,dst);source_sha=a.result();target_sha=b.result()
     assert source_sha==target_sha,'SHA256 mismatch '+str(dst)
     st=src.stat();assert (st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns']),'Source changed '+str(src)
     state['verified_files']+=1;state['verified_bytes']+=row['bytes'];log.write(json.dumps(dict(row,sha256=source_sha,status='verified'),ensure_ascii=False)+'\n')
   except Exception as e:state['failed'].append({'path':rel,'error_type':type(e).__name__,'error':str(e)})
   if time.monotonic()-last>=5:log.flush();state['checked_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();last=time.monotonic()
 after,after_digest=inventory();state['source_metadata_unchanged']=before_digest==after_digest;state['source_inventory_after_sha256']=after_digest
 state.update(status='readable_files_verified_unreadable_retained' if not state['failed'] and before_digest==after_digest else 'verification_failed_sources_retained',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),final_disk_flush_pending=True);save()
except BaseException as e:
 state.update(status='failed',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());save();raise
