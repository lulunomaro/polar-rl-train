import collections,gzip,hashlib,json,os,stat,time,traceback
from pathlib import Path
WS=Path('/mnt/robowork4t/workspaces/robomaster');CTL=WS/'migration/cleanup_20261123_01'
SAFE_COMPONENTS={'deriveddatacache','shadercache','shader_cache','shader-cache','glcache','computecache','dxcache','.pytest_cache','.mypy_cache','.ruff_cache'}
def main():
    groups=collections.defaultdict(lambda:{'files':0,'bytes':0,'allocated_bytes':0})
    selected=0;total=0;size_groups=collections.defaultdict(list);all_cache=[];instructions=set()
    outpath=CTL/'CACHE_CANDIDATES_01.jsonl.gz'
    with gzip.open(CTL/'SCAN_FILES_01.jsonl.gz','rt') as stream,gzip.open(outpath,'wt',compresslevel=3) as out:
        for line in stream:
            r=json.loads(line);parts=Path(r['p']).parts;root=None;kind=None
            for i,part in enumerate(parts[:-1]):
                name=part.casefold()
                if name in SAFE_COMPONENTS:
                    root='/'.join(parts[:i+1]);kind=name;break
                if name=='cache' and 'kit_isolation' in [p.casefold() for p in parts[:i]]:
                    root='/'.join(parts[:i+1]);kind='kit_cache';break
                if name=='__pycache__':
                    root='/'.join(parts[:i+1]);kind='python_bytecode';break
            if root is not None:
                r['cache_root']=root;r['kind']=kind
                out.write(json.dumps(r,separators=(',',':'))+'\n')
                selected+=1;total+=r['s'];v=groups[root];v['files']+=1;v['bytes']+=r['s'];v['allocated_bytes']+=r['b'];v['kind']=kind
            elif r['s']>=8*1024*1024 and '.git' not in parts:
                size_groups[r['s']].append(r)
            if parts[-1]=='AGENTS.md': instructions.add(r['p'])
    same_size=[rows for rows in size_groups.values() if len(rows)>1]
    result={'status':'analyzed','files':selected,'bytes':total,'allocated_bytes':sum(v['allocated_bytes'] for v in groups.values()),'cache_roots':dict(sorted(groups.items(),key=lambda kv:-kv[1]['bytes'])),'by_kind':{},'duplicate_size_groups':len(same_size),'duplicate_size_files':sum(map(len,same_size)),'duplicate_size_upper_bound_bytes':sum(rows[0]['s']*(len(rows)-1) for rows in same_size),'candidate_manifest':str(outpath),'candidate_manifest_sha256':hashlib.file_digest(outpath.open('rb'),'sha256').hexdigest(),'instruction_files':sorted(instructions)}
    by_kind=collections.defaultdict(lambda:{'files':0,'bytes':0,'roots':0})
    for v in groups.values():
        b=by_kind[v['kind']];b['files']+=v['files'];b['bytes']+=v['bytes'];b['roots']+=1
    result['by_kind']=dict(by_kind)
    (CTL/'CACHE_ANALYSIS_01.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    with gzip.open(CTL/'LARGE_SAME_SIZE_GROUPS_01.jsonl.gz','wt',compresslevel=3) as stream:
        for rows in same_size:stream.write(json.dumps(rows,separators=(',',':'))+'\n')
    print(json.dumps({'status':'complete','files':selected,'bytes':total,'by_kind':dict(by_kind),'duplicate_size_upper_bound_bytes':result['duplicate_size_upper_bound_bytes']},ensure_ascii=True),flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        (CTL/'CACHE_ANALYSIS_FAILURE_01.json').write_text(json.dumps({'traceback':traceback.format_exc()}));raise
