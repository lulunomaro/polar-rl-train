import argparse,collections,gzip,hashlib,json,os,re,stat,subprocess,time,traceback
from pathlib import Path
from datetime import datetime,timezone
WS=Path('/mnt/robowork4t/workspaces/robomaster');CTL=WS/'migration/cleanup_20261123_01'
ALLOWED={'python_bytecode','.pytest_cache','.mypy_cache','.ruff_cache','shadercache','shader_cache','shader-cache','deriveddatacache','kit_cache','computecache','glcache','dxcache'}
def utc():return datetime.now(timezone.utc).isoformat()
def save(name,value):
    p=CTL/(name+'.tmp');p.write_text(json.dumps(value,ensure_ascii=True,indent=2),encoding='utf-8');os.replace(p,CTL/name)
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def context(path):
    rel=path.relative_to(WS);parts=rel.parts
    if len(parts)>=6 and parts[:5]==('history','host210','mod4_windows_data','MOD4_training_data','rl_candidates'):return WS.joinpath(*parts[:6])
    if len(parts)>=4 and parts[0]=='history':return WS.joinpath(*parts[:4])
    if len(parts)>=2 and parts[0]=='mjcf':return WS.joinpath(*parts[:2])
    return path
def processes():
    matches=[];open_paths=[];denied=0
    alias='/home/egde/rl_candidates';target=str(WS/'history/host210/mod4_windows_data/MOD4_training_data/rl_candidates')
    own=os.getpid()
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==own:continue
        refs=set();cwd=None
        try:
            cwd=os.readlink(p/'cwd')
            if cwd.startswith(str(WS)+'/'):refs.add(str(context(Path(cwd.removesuffix(' (deleted)')))))
        except OSError:pass
        try:
            args=(p/'cmdline').read_bytes().split(b'\0')
            for raw in args:
                a=raw.decode('utf-8',errors='replace')
                if a.startswith('--') and '=' in a:a=a.split('=',1)[1]
                a=a.replace(alias,target)
                if a.startswith(str(WS)+'/') and '\n' not in a:
                    refs.add(str(context(Path(a))))
        except OSError:pass
        try:
            for fd in (p/'fd').iterdir():
                try:
                    t=os.readlink(fd).removesuffix(' (deleted)')
                    if t.startswith(str(WS)+'/'):open_paths.append({'pid':int(p.name),'path':t})
                except OSError:pass
        except PermissionError:denied+=1
        except OSError:pass
        if refs:
            try:comm=(p/'comm').read_text().strip()
            except OSError:comm='unknown'
            matches.append({'pid':int(p.name),'comm':comm,'cwd':cwd,'contexts':sorted(refs)})
    return {'workspace_processes':matches,'workspace_open_files':open_paths,'fd_permission_denied_processes':denied}
def protected(path,live):
    ctxt=str(context(path));reasons=[]
    for proc in live['workspace_processes']:
        if ctxt in proc['contexts']:reasons.append('active_context_pid_'+str(proc['pid']))
    root=path
    for opened in live['workspace_open_files']:
        op=Path(opened['path'])
        if op==path or op.is_relative_to(root):reasons.append('open_file_pid_'+str(opened['pid']))
    return reasons

def python_source(path):
    if path.suffix not in ('.pyc','.pyo'):return None
    name=path.name
    if path.parent.name=='__pycache__':
        stem=re.split(r'\.(?:cpython|pypy)[-.]',name,maxsplit=1)[0]
        if stem==name:return None
        return path.parent.parent/(stem+'.py')
    return path.with_suffix('.py')
def validate(row):
    path=WS/row['p'];root=WS/row['cache_root']
    if row['kind'] not in ALLOWED:return 'unapproved_cache_kind'
    if not path.is_relative_to(WS) or not root.is_relative_to(WS) or not path.is_relative_to(root):return 'outside_scope'
    try:
        if path.resolve(strict=True)!=path:return 'symlink_or_redirected_parent'
        info=path.lstat()
    except OSError as e:return 'unreadable_or_missing:'+str(e)
    if not stat.S_ISREG(info.st_mode):return 'not_regular'
    if (info.st_size,info.st_mtime_ns,info.st_ino)!=(row['s'],row['m'],row['i']):return 'changed_since_scan'
    if row['kind']=='python_bytecode':
        source=python_source(path)
        if source is None or not source.is_file():return 'bytecode_without_confirmed_source'
    return None

def prepare():
    assert not(CTL/'CLEANUP_STARTED.json').exists(),'actual cleanup already started'
    analysis=json.loads((CTL/'CACHE_ANALYSIS_01.json').read_text());live=processes()
    selected=[];skipped=[];roots={};by_kind=collections.defaultdict(lambda:{'files':0,'bytes':0,'allocated_bytes':0})
    with gzip.open(CTL/'CACHE_CANDIDATES_01.jsonl.gz','rt') as stream:
        for line in stream:
            row=json.loads(line);p=WS/row['p'];root=WS/row['cache_root']
            if row['cache_root'] not in roots:roots[row['cache_root']]=protected(root,live)
            reason=','.join(roots[row['cache_root']]) or validate(row)
            if reason:skipped.append({'p':row['p'],'bytes':row['s'],'reason':reason});continue
            selected.append(row);v=by_kind[row['kind']];v['files']+=1;v['bytes']+=row['s'];v['allocated_bytes']+=row['b']
    plan=CTL/'CLEANUP_PLAN_01.jsonl.gz'
    with gzip.open(plan,'wt',compresslevel=3) as out:
        for row in selected:out.write(json.dumps(row,separators=(',',':'))+'\n')
    applicable={}
    for name in analysis['instruction_files']:
        p=WS/name
        if any((WS/r['p']).is_relative_to(p.parent) for r in selected):
            raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest()
            if sha not in applicable:applicable[sha]={'paths':[],'sha256':sha,'text':raw.decode('utf-8-sig',errors='replace')}
            applicable[sha]['paths'].append(name)
    save('APPLICABLE_INSTRUCTIONS_01.json',list(applicable.values()))
    save('CLEANUP_PLAN_SUMMARY_01.json',{'status':'prepared','utc':utc(),'planned_files':len(selected),'planned_bytes':sum(r['s'] for r in selected),'by_kind':dict(by_kind),'plan_sha256':digest(plan),'skipped':skipped,'live':live,'root_count':len({r['cache_root'] for r in selected}),'instructions_unique':len(applicable),'content_hashing':'Cache payloads are disposable and reconstructible. No full 115GB payload hashing; exact original path/size/mtime/inode plus actual deletion outcome are retained. Manifest SHA256 is computed. Unique reports, model weights, datasets and CAD are outside this cleanup plan.'})
    print(json.dumps({'status':'prepared','files':len(selected),'bytes':sum(r['s'] for r in selected),'by_kind':dict(by_kind),'skipped':len(skipped),'instructions_unique':len(applicable)},ensure_ascii=True),flush=True)

def execute(expected):
    plan=CTL/'CLEANUP_PLAN_01.jsonl.gz'
    assert digest(plan)==expected,'reviewed plan mismatch'
    assert not(CTL/'CLEANUP_STARTED.json').exists(),'cleanup already started: follow existing receipts'
    mount=json.loads(subprocess.check_output(['findmnt','-J','-T',str(WS),'-o','TARGET,UUID,FSTYPE'],text=True))['filesystems'][0]
    assert mount['target']=='/mnt/robowork4t' and mount['uuid'].upper()=='AFEF50F71FC9187D' and mount['fstype']=='ntfs3',mount
    before=os.statvfs(WS);free_before=before.f_bavail*before.f_frsize
    live=processes();save('CLEANUP_STARTED.json',{'pid':os.getpid(),'utc':utc(),'plan_sha256':expected,'free_bytes_before':free_before,'live':live,'nonrecursive_file_deletion':True})
    count=0;removed_bytes=0;removed_allocated=0;skipped=[];errors=[];dirs=set();by_kind=collections.defaultdict(lambda:{'files':0,'bytes':0,'allocated_bytes':0});last=0
    receipts=CTL/'DELETED_CACHE_FILES_01.jsonl.gz'
    with gzip.open(plan,'rt') as stream,gzip.open(receipts,'wt',compresslevel=3) as out:
        for line in stream:
            row=json.loads(line);path=WS/row['p'];root=WS/row['cache_root']
            reason=','.join(protected(root,live)) or validate(row)
            if reason:skipped.append({'p':row['p'],'bytes':row['s'],'reason':reason});continue
            try:
                path.unlink()
                out.write(json.dumps({**row,'result':'deleted','utc':utc()},separators=(',',':'))+'\n')
                count+=1;removed_bytes+=row['s'];removed_allocated+=row['b'] if row['n']==1 else 0
                v=by_kind[row['kind']];v['files']+=1;v['bytes']+=row['s'];v['allocated_bytes']+=row['b'] if row['n']==1 else 0
                parent=path.parent
                while parent.is_relative_to(root):dirs.add(parent);parent=parent.parent
            except OSError as exc:errors.append({'p':row['p'],'error':str(exc)})
            if time.monotonic()-last>10:
                save('CLEANUP_PROGRESS.json',{'utc':utc(),'files':count,'bytes':removed_bytes,'skipped':len(skipped),'errors':len(errors)});last=time.monotonic()
    removed_dirs=0
    for directory in sorted(dirs,key=lambda p:len(p.parts),reverse=True):
        try:directory.rmdir();removed_dirs+=1
        except OSError:pass
    subprocess.run(['sync','-f','/mnt/robowork4t'],check=True,timeout=120)
    after=os.statvfs(WS);free_after=after.f_bavail*after.f_frsize
    result={'status':'complete','utc':utc(),'deleted_files':count,'deleted_bytes':removed_bytes,'deleted_allocated_bytes_estimate':removed_allocated,'removed_empty_cache_directories':removed_dirs,'by_kind':dict(by_kind),'skipped':skipped,'errors':errors,'free_bytes_before':free_before,'free_bytes_after':free_after,'measured_free_bytes_increase':free_after-free_before,'deleted_manifest':str(receipts),'deleted_manifest_bytes':receipts.stat().st_size,'deleted_manifest_sha256':digest(receipts),'no_training_or_unique_artifact_deletion':True,'final_disk_sync':True}
    save('CLEANUP_RESULT_01.json',result);print(json.dumps(result,ensure_ascii=True),flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['prepare','execute'],required=True);ap.add_argument('--plan-sha');args=ap.parse_args()
    try:
        if args.mode=='prepare':prepare()
        else:execute(args.plan_sha)
    except Exception:
        save('CLEANUP_'+args.mode.upper()+'_FAILURE_01.json',{'utc':utc(),'traceback':traceback.format_exc()});raise
