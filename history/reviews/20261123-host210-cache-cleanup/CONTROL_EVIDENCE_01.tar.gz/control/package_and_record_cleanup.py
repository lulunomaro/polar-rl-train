import hashlib,io,json,os,shutil,subprocess,sys,tarfile
from pathlib import Path
WS=Path('/mnt/robowork4t/workspaces/robomaster');CTL=WS/'migration/cleanup_20261123_01';REPO=WS/'mjcf/polar-rl-train'
REL=Path('history/reviews/20261123-host210-cache-cleanup');DEST=REPO/REL
BASE='39c408937be8e2319b2b040d6ab73a95ee8b1b37';ID='host210-cache-cleanup-01';TAG='trial-20261123-'+ID
sys.path.insert(0,str(REPO/'archive_tools'))
from capture_history import redact

def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],text=True).strip()
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    assert json.loads((CTL/'CLEANUP_RESULT_01.json').read_text())['status']=='complete'
    assert git('rev-parse','HEAD')==BASE,'Target main changed; reconcile before recording'
    assert not git('tag','--list',TAG),'Trial exists: never re-record'
    assert not git('diff','--cached','--name-only'),'Existing staged work must be preserved'
    lock=REPO/'.git/index.lock';assert not lock.exists(),'Existing Git operation still owns index'
    for key,fmt in [('user.name','%an'),('user.email','%ae')]:
        current=subprocess.run(['git','-C',str(REPO),'config','--get',key],capture_output=True,text=True)
        if current.returncode:subprocess.run(['git','-C',str(REPO),'config',key,git('show','-s','--format='+fmt,'HEAD')],check=True)
    DEST.mkdir(parents=True,exist_ok=True)
    archive=DEST/'CONTROL_EVIDENCE_01.tar.gz';assert not archive.exists(),'Evidence already packaged; inspect existing state'
    originals=[p for p in sorted(CTL.iterdir()) if p.is_file() and p.suffix!='.tmp' and p.name not in {'cleanup_trial.bundle'}]
    index=[];redacted_files=0
    with tarfile.open(archive,'w:gz',compresslevel=5) as tar:
        for p in originals:
            raw=p.read_bytes();before=p.stat();archived=raw;did_redact=False
            try:
                text=raw.decode('utf-8');clean=redact(text)[0]
                if clean!=text:archived=clean.encode('utf-8');did_redact=True;redacted_files+=1
            except UnicodeDecodeError:pass
            info=tarfile.TarInfo('control/'+p.name);info.size=len(archived);info.mtime=int(before.st_mtime);info.mode=0o644
            tar.addfile(info,io.BytesIO(archived))
            after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'Mutable control file '+p.name
            index.append({'original_path':str(p),'original_bytes':len(raw),'original_sha256':hashlib.sha256(raw).hexdigest(),'archive_member':'control/'+p.name,'archive_bytes':len(archived),'archive_sha256':hashlib.sha256(archived).hexdigest(),'redacted':did_redact})
    payload={'stage':'workspace-cleanup-20261123-01','control_root':str(CTL),'archive_git_path':(REL/archive.name).as_posix(),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'entries':index,'redacted_files':redacted_files,'reader_failures_preserved':3,'unique_model_or_dataset_files_removed':0}
    (DEST/'EVIDENCE_INDEX_01.json').write_text(json.dumps(payload,ensure_ascii=True,indent=2),encoding='utf-8')
    for name in ['RESULT.md','CLEANUP_RESULT_01.json','CLEANUP_PLAN_SUMMARY_01.json','READ_ONLY_ATTEMPTS_01.json','LOCAL_READER_FAILURE_01.json']:
        raw=(CTL/name).read_bytes()
        try:
            text=raw.decode('utf-8');assert redact(text)[0]==text,'Credential found in summary; archive sanitized copy instead'
        except UnicodeDecodeError:pass
        (DEST/name).write_bytes(raw)
    files=[str((REL/p.name).as_posix()) for p in sorted(DEST.iterdir()) if p.is_file()]
    print(json.dumps({'status':'packaged','archive_bytes':payload['archive_bytes'],'archive_sha256':payload['archive_sha256'],'entries':len(index),'redacted_files':redacted_files},ensure_ascii=True),flush=True)
    args=['/usr/bin/python3',str(REPO/'archive_tools/record_experiment.py'),'--id',ID,'--title','Clean reconstructible caches from migrated host210 workspace','--kind','repair','--note-file',str(DEST/'RESULT.md'),'--files',*files,'--validation','15219 cache files removed; 115648483306 payload bytes; measured free-space increase 115684937728 bytes; unique artifacts kept; reader failures preserved.']
    completed=subprocess.run(args,capture_output=True,text=True)
    if completed.returncode:
        failure={'operation':'record_experiment','returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr}
        (CTL/'GIT_RECORD_FAILURE_01.json').write_text(json.dumps(failure,indent=2));print(json.dumps(failure),flush=True);raise SystemExit(completed.returncode)
    head=git('rev-parse','HEAD');tagobj=git('rev-parse',TAG);peeled=git('rev-parse',TAG+'^{}')
    assert peeled==head
    bundle=CTL/'cleanup_trial.bundle'
    subprocess.run(['git','-C',str(REPO),'bundle','create',str(bundle),'HEAD','refs/tags/'+TAG,'^'+BASE],check=True)
    print(json.dumps({'status':'recorded_bundle_ready','head':head,'tag':TAG,'tag_object':tagobj,'peeled':peeled,'bundle':str(bundle),'bundle_bytes':bundle.stat().st_size,'bundle_sha256':sha(bundle),'record_stdout':completed.stdout.strip()},ensure_ascii=True),flush=True)
if __name__=='__main__':main()
