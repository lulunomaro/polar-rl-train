import collections, gzip, hashlib, heapq, json, os, stat, time, traceback
from pathlib import Path
from datetime import datetime, timezone
WORKSPACE = Path('/mnt/robowork4t/workspaces/robomaster')
CONTROL = WORKSPACE / 'migration/cleanup_20261123_01'
ROOTS = [WORKSPACE/'mjcf', WORKSPACE/'history/local_F/RMPOLAR-RL', WORKSPACE/'history/host210/mod4_windows_data']
CACHE_NAMES = {'__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.cache','node_modules','.venv','venv','.tox','.nox'}
def dump(name, value):
    temporary = CONTROL/(name+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=True, indent=2), encoding='utf-8')
    os.replace(temporary, CONTROL/name)
def now(): return datetime.now(timezone.utc).isoformat()
def main():
    assert not (CONTROL/'SCAN_STARTED.json').exists(), 'scan already started; follow existing receipt'
    started=time.monotonic()
    dump('SCAN_STARTED.json', {'stage':'workspace-cleanup-20261123-01','pid':os.getpid(),'utc':now(),'roots':[str(p) for p in ROOTS],'read_only':True})
    rootdev=WORKSPACE.stat().st_dev
    count=0; total=0; directories=0; links=0; allocated=0; errors=[]; skipped_mounts=[]
    by_group=collections.defaultdict(lambda:[0,0,0])
    by_ext=collections.defaultdict(lambda:[0,0])
    caches={}; large=[]; archives=[]; bytecode=[0,0]; temporary_dirs=[]
    manifest=CONTROL/'SCAN_FILES_01.jsonl.gz'
    last_progress=0
    with gzip.open(manifest,'wt',encoding='utf-8',compresslevel=3) as out:
        stack=[(p,None) for p in reversed(ROOTS)]
        while stack:
            directory, cache=stack.pop()
            relative=str(directory.relative_to(WORKSPACE))
            if cache is None and directory.name in CACHE_NAMES:
                cache=relative
                caches[cache]={'files':0,'bytes':0,'allocated_bytes':0}
            if directory.name.startswith(('unpack_verify','unpack_','tmp_','temp_')):
                temporary_dirs.append(relative)
            directories+=1
            try:
                with os.scandir(directory) as entries:
                    for entry in entries:
                        try:
                            info=entry.stat(follow_symlinks=False)
                            path=Path(entry.path); rel=str(path.relative_to(WORKSPACE))
                            if stat.S_ISLNK(info.st_mode):
                                links+=1; continue
                            if info.st_dev!=rootdev:
                                skipped_mounts.append(rel); continue
                            if stat.S_ISDIR(info.st_mode):
                                stack.append((path,cache)); continue
                            if not stat.S_ISREG(info.st_mode): continue
                            record={'p':rel,'s':info.st_size,'m':info.st_mtime_ns,'b':info.st_blocks*512,'i':info.st_ino,'n':info.st_nlink}
                            out.write(json.dumps(record,ensure_ascii=True,separators=(',',':'))+'\n')
                            count+=1; total+=info.st_size; allocated+=info.st_blocks*512
                            parts=path.relative_to(WORKSPACE).parts
                            for depth in (1,2,3,4,5):
                                if len(parts)>depth:
                                    g='/'.join(parts[:depth]); v=by_group[g]; v[0]+=1; v[1]+=info.st_size; v[2]+=info.st_blocks*512
                            ext=''.join(path.suffixes[-2:]).lower() if path.name.endswith(('.tar.gz','.tar.xz','.tar.zst')) else path.suffix.lower()
                            by_ext[ext][0]+=1; by_ext[ext][1]+=info.st_size
                            if cache:
                                v=caches[cache];v['files']+=1;v['bytes']+=info.st_size;v['allocated_bytes']+=info.st_blocks*512
                            if ext in ('.pyc','.pyo'): bytecode[0]+=1;bytecode[1]+=info.st_size
                            if info.st_size>=256*1024*1024 and ext in ('.zip','.tar','.gz','.tar.gz','.tar.xz','.tar.zst','.7z','.rar'):
                                archives.append(record)
                            item=(info.st_size,rel)
                            if len(large)<160: heapq.heappush(large,item)
                            elif item>large[0]: heapq.heapreplace(large,item)
                        except OSError as exc:
                            errors.append({'path':entry.path,'error':str(exc)})
            except OSError as exc:
                errors.append({'path':str(directory),'error':str(exc)})
            if time.monotonic()-last_progress>10:
                dump('SCAN_PROGRESS.json',{'utc':now(),'files':count,'bytes':total,'directories':directories,'current':relative,'pending_directories':len(stack),'errors':len(errors),'elapsed_seconds':round(time.monotonic()-started,2)})
                last_progress=time.monotonic()
    result={'stage':'workspace-cleanup-20261123-01','status':'complete','utc':now(),'elapsed_seconds':time.monotonic()-started,'files':count,'bytes':total,'allocated_bytes':allocated,'directories':directories,'symlinks_not_followed':links,'groups':dict(sorted(by_group.items(),key=lambda kv:-kv[1][1])),'extensions':dict(sorted(by_ext.items(),key=lambda kv:-kv[1][1])),'cache_candidates':dict(sorted(caches.items(),key=lambda kv:-kv[1]['bytes'])),'bytecode':bytecode,'large_files':[{'bytes':s,'path':p} for s,p in sorted(large,reverse=True)],'large_archives':sorted(archives,key=lambda v:-v['s']),'temporary_dir_candidates':temporary_dirs,'errors':errors,'other_mounts_skipped':skipped_mounts,'manifest':str(manifest),'manifest_bytes':manifest.stat().st_size,'manifest_sha256':hashlib.file_digest(manifest.open('rb'),'sha256').hexdigest()}
    dump('SCAN_SUMMARY.json',result)
    print(json.dumps({'status':'complete','files':count,'bytes':total,'errors':len(errors),'elapsed_seconds':result['elapsed_seconds']},ensure_ascii=True),flush=True)
if __name__=='__main__':
    try: main()
    except Exception:
        dump('SCAN_FAILURE.json',{'utc':now(),'traceback':traceback.format_exc()})
        raise
